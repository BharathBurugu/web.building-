<section id="footer-top">
        <div class="container">
            <div class="row">
                <div id="socialmedia" class="text-center">
                    <div class="container">
                        <div class="welcome col-md-12">
                            <?php if (osc_is_home_page()) { ?>
                                <?php if( osc_is_web_user_logged_in() ) { ?>
                                    <h2><?php _e("Post an ad today. It's free!", 'liberty'); ?></h2>
                                    <h3><?php _e("Over", 'liberty'); ?> <?php echo osc_total_items(); ?> <?php _e("ads listed in", 'liberty'); ?> <?php echo osc_page_title()?>.</h3>
                                    <a class="btn btn-success btn-lg" href="<?php echo osc_item_post_url(); ?>"><?php _e("Post an ad", 'liberty'); ?></a>
                                <?php } else{ ?>
                                    <h2><?php _e("Sign up today. It's free!", 'liberty'); ?></h2>
                                    <h3><?php _e("Over", 'liberty'); ?> <?php echo osc_total_items(); ?> <?php _e("ads listed in", 'liberty'); ?> <?php echo osc_page_title()?>.</h3>
                                    <a class="btn btn-success btn-lg" href="<?php echo osc_user_login_url(); ?>"><?php _e("Get started", 'liberty'); ?></a>
                                <?php } ?>
                            <?php } else if (osc_is_search_page()) { ?>
                                <div class="m-cat">
                                    <ul>
                                        <?php	$i = 0; while ( osc_has_categories() ) { ?>
                                            <li>
                                                <a class="category <?php echo osc_category_slug(); ?>" href="<?php echo osc_search_category_url(); ?>">
                                                    <i class="<?php echo osc_esc_html( osc_get_preference('cat_icon_'.osc_category_id(), 'liberty_theme') ); ?>"></i>
                                                    <?php echo osc_category_name(); ?>
                                                </a>
                                            </li>
                                        <?php $i++; }  ?>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                        	<?php } else { ?>
                        		<div id="footer-widgets" class="text-left">
                                   <div class="row">
                                        <div class="col-md-2 col-sm-4 col-xs-12">
                                            <h4><?php _e('Quicklinks', 'liberty'); ?></h4>
                                            <div class="links">
                                                <ul>
                                                    <?php if( osc_get_preference('footer_menu_home', 'liberty_theme') !== '0') { ?>
                                                    <li><a href="<?php echo osc_base_url(); ?>"><?php _e('Home', 'liberty'); ?></a></li>
                                                    <?php } ?>
													<?php osc_reset_static_pages(); while( osc_has_static_pages() ) { ?>
                                                    <?php if( osc_get_preference('footer_menu_'.osc_static_page_id(), 'liberty_theme') !== '0') { ?>
                                                    <li><a href="<?php echo osc_static_page_url(); ?>"><?php echo osc_static_page_title(); ?></a></li>
                                                     <?php } ?>
                                                     <?php } ?>
                                                     <?php if( osc_get_preference('footer_menu_contact', 'liberty_theme') !== '0') { ?>
                                                    <li><a href="<?php echo osc_contact_url(); ?>"><?php _e('Contact', 'liberty'); ?></a></li>
                                                    <?php } ?>
                                                 </ul>
                                            </div>
                                        </div>
                                        <!-- Footer Widget #1 -->
                                        <?php if( osc_get_preference('widget_one', 'liberty_theme') !== '0') { 
                                            echo '<div class="col-md-5 hidden-xs"><h4>'.osc_get_preference("widget1_title", "liberty_theme").'</h4>
                                            <p>'.osc_get_preference("widget1_text", "liberty_theme").'</p></div>'; 
                                        } ?>
                                        <!--<div class="col-md-5 hidden-xs">
                                            <h4><?php echo osc_esc_html(__(osc_get_preference('widget1_title', 'liberty_theme'), 'liberty')); ?></h4>
                                            <p><?php echo osc_esc_html(__(osc_get_preference('widget1_text', 'liberty_theme'), 'liberty')); ?></p>
                                            <div class="links">
                                                <ul>
                                                    <li><i class="fa fa-map-marker"></i> 42 avenue des Champs Elyses</li>
                                                    <li><i class="fa fa-mobile-phone"></i> Phone: 0123-456-789</li>
                                                    <li><i class="fa fa-envelope"></i> Email: name@yourcompany.com</li>
                                                 </ul>
                                            </div>
                                        </div>-->
                                        <!-- Footer Widget #2 -->
                                        <?php if( osc_get_preference('widget_two', 'liberty_theme') !== '0') { 
                                            echo '<div class="col-md-5 hidden-xs hidden-sm"><h4>'.osc_get_preference("widget2_title", "liberty_theme").'</h4>
                                            <p>'.osc_get_preference("widget2_text", "liberty_theme").'</p></div>'; 
                                        } ?>
                                    </div>
                                  </div><!--footer-widget-end-->
                        	<?php }?>
                           
                    </div>
                    
                </div>
            </div>
        </div>
        </div>
    </section>
    
    <section id="footer-bottom">
        <div class="container">
           <div class="row">
                <div class="col-sm-6">
                   <div class="copyright">
                        &copy; <?php print date("Y")?> <?php echo osc_page_title(); ?>. All Rights Reserved. <?php
                        if( osc_get_preference('footer_link', 'liberty_theme') !== '0') { echo 'Powered by <a title="Osclass web" href="http://osclass.org/">Osclass</a>';
                        } ?>
                    </div>
                    </div>
                    <div class="col-sm-6 hidden-xs">
                        <div class="pull-right">
                        <?php _e('Designed and Developed by <a target="_blank"  href="http://www.drizzlethemes.com/" title="Liberty Osclass Theme - DrizzleThemes">DrizzleThemes</a>', 'liberty'); ?>
                        </div>
                    </div>
                </div>
           </div>
    </section>
    
</div><!--/#page dont remove this-->

<?php osc_run_hook('footer'); ?>
<script src="<?php echo osc_current_web_theme_url('js/bootstrap.min.js') ; ?>"  type="text/javascript"></script>

<?php /*?><script type="text/javascript">
$(function() {
 $(".dropdown").hover(
  function(){ $(this).addClass('open') },
  function(){ $(this).removeClass('open') }
 );
});
</script><?php */?>
<script type="text/javascript">$(".flashmessage .ico-close").click(function(){$(this).parent().hide();});</script>
<script>
$(document).ready(function(){
$(".paginate span.searchPaginationSelected").addClass("btn btn-success disabled btn-md");
$(".paginate a").addClass("btn btn-primary btn-md");
$('a.searchPaginationNext').empty().append("Next <small>></small>");
$('a.searchPaginationPrev').empty().append("<small><</small> Prev");
});
</script>
</body>
</html>