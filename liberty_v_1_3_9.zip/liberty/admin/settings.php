<link href="<?php echo osc_current_web_theme_url('css/bootstrap.min.css'); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo osc_current_web_theme_url('css/font-awesome.min.css'); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo osc_current_web_theme_url('css/iconmoon.css'); ?>" rel="stylesheet" type="text/css" />
<script src="<?php echo osc_current_web_theme_url('js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo osc_current_web_theme_url('admin/jscolor/jscolor.js'); ?>"></script>

<style type="text/css" media="screen">
@import "http://fonts.googleapis.com/css?family=Lobster";
	#content-head { height:auto;background: none repeat scroll 0 0 #0b455b; color:#fff;}
	#content-head a, #content-head a:hover { color:#fff; }
	.tab-content { padding-top:20px!important;}
    .form-control { height:auto!important; padding:7px!important; width:100%!important; }
	.select-box select { opacity:10!important;}
	small { font-size:11px; color:#666666;}
	#content-page {background: none repeat scroll 0 0 #f7f7f7;}
	#content-head h2 { color: #fff !important;  font-size: 50px;
    font-weight: bold;
    margin-top: -7px;
	font-family:Lobster;}
.tab-content {
  -moz-border-bottom-colors: none;
  -moz-border-left-colors: none;
  -moz-border-right-colors: none;
  -moz-border-top-colors: none;
  background: none repeat scroll 0 0 #fff;
  border-bottom: 1px solid #e2e2e2;
  border-image: none;
  border-left: 1px solid #e2e2e2;
  border-radius: 3px;
  border-right: 1px solid #e2e2e2;
  border-top: medium none !important;
 
} 
a{outline:none !important;}
.btn:hover, .btn:focus {color:#fff; }
#caticon span {
  font-size: 23px;
}
</style>

<?php if ( (!defined('ABS_PATH')) ) exit('ABS_PATH is not loaded. Direct access is not allowed.'); ?>
<?php if ( !OC_ADMIN ) exit('User access is not allowed.'); ?>
<?php  $info   = WebThemes::newInstance()->loadThemeInfo(osc_theme());?>
<h2 class="render-title <?php echo (osc_get_preference('footer_link', 'liberty_theme') ? '' : 'separate-top'); ?>"><?php _e('Liberty Theme settings', 'liberty'); ?></h2>
<form action="<?php echo osc_admin_render_theme_url('oc-content/themes/liberty/admin/settings.php'); ?>" method="post" class="nocsrf">
    <input type="hidden" name="action_specific" value="settings" />
    
   <div class="admin-tab">
         	
      <!-- tabs left -->
      <div class="tabbable tabs-left">
        <ul class="nav nav-tabs">
          <li class="active"><a href="#gen1" data-toggle="tab">General</a></li>
          <li><a href="#menumgr" data-toggle="tab">Menu Manager</a></li>
          <li><a href="#pag" data-toggle="tab">Page/Social Links</a></li>
          <li><a href="#ico" data-toggle="tab">Category Icons</a></li>
          <li><a href="#wid" data-toggle="tab">Widgets</a></li>
          <li><a href="#foo" data-toggle="tab">Footer</a></li>
          <li><a href="#plg" data-toggle="tab">Supported plugins</a></li>
        </ul>
        <div class="tab-content">
        	<div class="tab-pane active" id="gen1">
        		<div class="panel-body">
                
      				<div class="form-group clearfix">
                    	<label class="col-sm-3 control-label"><?php _e('Color', 'Liberty'); ?> <sup>beta</sup></label>
                        <div class="col-sm-4">
                            <input type="text" class="form-control color" name="color_sch" value="<?php echo osc_esc_html( osc_get_preference('color_sch', 'liberty_theme') ); ?>">
                            <br />
                            <input type="checkbox" name="color_def" value="1" <?php echo (osc_get_preference('color_def', 'liberty_theme') ? 'checked' : ''); ?>> Show Default
                            <br /><small>Check to disable color chooser(Use default theme color). </small>
                        </div>
                	</div><!--/color-->
                
            		<div class="form-group clearfix">
                		<label class="col-sm-3 control-label"><?php _e('Search placeholder', 'liberty'); ?></label>
                 		<div class="col-sm-4">
                    		<input type="text" class="form-control" name="keyword_placeholder" value="<?php echo osc_esc_html( osc_get_preference('keyword_placeholder', 'liberty_theme') ); ?>">		
                 		</div>
            		</div><!--/place holder end-->
            
             		<div class="form-group clearfix">
                		<label class="col-sm-3 control-label"><?php _e('Show lists as:', 'liberty'); ?></label>
                		<div class="col-sm-4">
                        <select class="form-control" name="defaultShowAs@all">
                            <option value="gallery" <?php if(liberty_default_show_as() == 'gallery'){ echo 'selected="selected"' ; } ?>><?php _e('Gallery','liberty'); ?></option>
                            <option value="list" <?php if(liberty_default_show_as() == 'list'){ echo 'selected="selected"' ; }�?>><?php _e('List','liberty'); ?></option>
                        </select>
               			</div>
            		</div><!--/show list as-->
            
              		<div class="form-group clearfix">
                		<label class="col-sm-3 control-label"><?php _e('Location Filter', 'liberty'); ?></label>
                		<div class="col-sm-4">
							<select class="form-control" name="defaultCountry@all">
                    			<option value="c_r_c" <?php if(liberty_def_country() == 'c_r_c'){ echo 'selected="selected"' ; }�?>><?php _e('Countries, Regions, Cities ','liberty'); ?></option>
                        		<option value="r_c" <?php if(liberty_def_country() == 'r_c'){ echo 'selected="selected"' ; } ?>><?php _e('Region, Cities','liberty'); ?></option>
                        		<option value="country" <?php if(liberty_def_country() == 'country'){ echo 'selected="selected"' ; } ?>><?php _e('Countries only','liberty'); ?></option>
                        		<option value="region" <?php if(liberty_def_country() == 'region'){ echo 'selected="selected"' ; } ?>><?php _e('Region only','liberty'); ?></option>
                        		<option value="city" <?php if(liberty_def_country() == 'city'){ echo 'selected="selected"' ; } ?>><?php _e('City only','liberty'); ?></option>
                    		</select>
               			 </div>
            		</div><!--/filterlocation-->
          
            		<div class="form-group clearfix">
                        <label class="col-sm-3 control-label"><?php _e('Post ad button text', 'liberty'); ?></label>
                         <div class="col-sm-4">
                            <input type="text" class="form-control" name="post_btn" value="<?php echo osc_esc_html( osc_get_preference('post_btn', 'liberty_theme') ); ?>">		
                         </div>
                    </div><!--/postad button text-->
         
                    <div class="form-group clearfix">
                        <label class="col-sm-3 control-label"><?php _e('Premium text', 'liberty'); ?></label>
                         <div class="col-sm-4">
                            <input type="text" class="form-control" name="premium_text" value="<?php echo osc_esc_html( osc_get_preference('premium_text', 'liberty_theme') ); ?>">		
                         </div>
                    </div><!--/Premium text-->
            
            		<div class="form-group clearfix">
                        <label class="col-sm-3 control-label"><?php _e('Welcome text', 'liberty'); ?></label>
                         <div class="col-sm-4">
                            <input type="text" class="form-control" name="welcome_text" value="<?php echo osc_esc_html( osc_get_preference('welcome_text', 'liberty_theme') ); ?>">		
                         </div>
                    </div><!--/welcome text-->
                    <hr />
           
          			<div class="form-group">
        				<label class="col-sm-3 control-label"><?php _e('Custom CSS', 'liberty'); ?></label>
                    	<div class="col-sm-4">
                    		<textarea class="form-control" rows="5" style="margin:10px 0 0 0;"  name="custom_css"><?php echo osc_get_preference('custom_css', 'liberty_theme', "UTF-8"); ?></textarea>
                        	<small>You can put your custom css here</small>
                    	</div>
        			</div><!-- /custom css -->
                  <div class="clearfix"></div>
                <br />  
                
                <div class="form-group">
        			<label class="col-sm-3 control-label"><?php _e('Landing page POPUP', 'liberty'); ?></label>
                    <div class="col-sm-4">
                    	<input type="checkbox" name="pop_enable" value="1" <?php echo (osc_get_preference('pop_enable', 'liberty_theme') ? 'checked' : ''); ?>> Enable or Disable
                        <input type="checkbox" name="pop_once" value="1" <?php echo (osc_get_preference('pop_once', 'liberty_theme') ? 'checked' : ''); ?>> Only once
                    	<!--<input class="form-control" type="text" name="pop_heading" value="<?php //echo osc_get_preference('pop_heading', 'liberty_theme', "UTF-8"); ?>" />-->
                    	<textarea class="form-control" rows="5" style="margin:10px 0 0 0;"  name="landing_pop"><?php echo osc_get_preference('landing_pop', 'liberty_theme', "UTF-8"); ?></textarea>
                    </div>
        		</div><!-- /Landing POP -->
                
                <div class="clearfix"></div>
                <br />
                    	<!---Google Publication Id-->
                <div class="form-group">
        			<div class="col-sm-offset-3 col-sm-8">
                        <label><input type="checkbox" name="google_ad" value="1" <?php echo (osc_get_preference('google_ad', 'liberty_theme') ? 'checked' : ''); ?>> Enable Adsense 
                            <br /><small>(Place following code to wherever you need to show ad: &lt;?php show_adsense(); ?&gt) </small>
                        </label>
          			</div>
        		</div>
       			<!-- field end -->
                <div class="clearfix"></div>
                <br />
       
                <div class="form-group clearfix">
                    <label class="col-sm-3 control-label"><?php _e('Google Publication ID', 'liberty'); ?> </label>
                    <div class="col-sm-4">
                        <input type="text" class="form-control" name="google_pub" value="<?php echo osc_esc_html( osc_get_preference('google_pub', 'liberty_theme') ); ?>" />
                        <small>Google Adsense ID ie.9187648588853292.<a href="https://www.google.com/adsense/" target="_blank">Get it here</a></small>
                    </div>
                </div>
                <!-- field end -->
                 <div class="clearfix"></div>
          
        	</div><!--/panbody-->
    	</div><!--genral end-->
        
        	<div class="tab-pane" id="menumgr">
        		<div class="panel-body">
                	<h4>Create New page <a href="" rel="nofollow" target="_blank">here <i class="fa fa-external-link"></i></a></h4>
                	<div class="form-group">
                   		<label class="control-label"><?php _e('Main menu', 'liberty'); ?></label>
                    	<ul>
                        	<li><label><input type="checkbox" name="main_menu_home" value="1" <?php echo (osc_get_preference('main_menu_home', 'liberty_theme') ? 'checked' : ''); ?> > <?php _e('Home', 'liberty'); ?></label></li>
                       		<?php osc_reset_static_pages(); while( osc_has_static_pages() ) { ?> 
                        	<li><label><input type="checkbox" name="main_menu_<?php echo osc_static_page_id();?>" value="1" <?php echo (osc_get_preference('main_menu_'.osc_static_page_id(), 'liberty_theme') ? 'checked' : ''); ?> > <?php echo osc_static_page_title(); ?></label></li>				
						<?php } ?>
                        	<li><label><input type="checkbox" name="main_menu_contact" value="1" <?php echo (osc_get_preference('main_menu_contact', 'liberty_theme') ? 'checked' : ''); ?> > <?php _e('Contact', 'liberty'); ?></label></li>
                       	</ul>
                   	</div>
             		<div class="form-group">
                    	<label class=" control-label"><?php _e('Footer menu', 'liberty'); ?></label>
                    		<ul>
                        		<li><label><input type="checkbox" name="footer_menu_home" value="1" <?php echo (osc_get_preference('footer_menu_home', 'liberty_theme') ? 'checked' : ''); ?> > <?php _e('Home', 'liberty'); ?></label></li>
                        		<?php osc_reset_static_pages(); while( osc_has_static_pages() ) { ?> 
                        		<li><label><input type="checkbox" name="footer_menu_<?php echo osc_static_page_id();?>" value="1" <?php echo (osc_get_preference('footer_menu_'.osc_static_page_id(), 'liberty_theme') ? 'checked' : ''); ?> > <?php echo osc_static_page_title(); ?></label></li>				
								<?php } ?>
                        		<li><label><input type="checkbox" name="footer_menu_contact" value="1" <?php echo (osc_get_preference('footer_menu_contact', 'liberty_theme') ? 'checked' : ''); ?> > <?php _e('Contact', 'liberty'); ?></label></li>
                       		</ul>
                    	</div>
                        
            		</div><!--/panbody-->
    			</div><!--menu end-->
                <div class="clearfix"></div>
        
   		<div class="tab-pane" id="pag">
   			<div class="panel-body">
            
          		<div class="form-group clearfix">
                    <label class="col-sm-3 control-label"><?php _e('Terms Page link', 'liberty'); ?></label>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" name="terms_link" value="<?php echo osc_esc_html( osc_get_preference('terms_link', 'liberty_theme') ); ?>">
                      <small>Paste full link of page url Ex: yourdomain.com/terms</small>
                    </div>
                </div><!--/ terms -->
                
            	<div class="form-group clearfix">
                    <label class="col-sm-3 control-label"><?php _e('Privacy page link', 'liberty'); ?></label>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" name="privacy_link" value="<?php echo osc_esc_html( osc_get_preference('privacy_link', 'liberty_theme') ); ?>">
                      <small>Paste full link of page url Ex: yourdomain.com/privacy</small>
                    </div>
                </div>
                <!--/ privacy -->
               	<hr />
                
            	<div class="form-group clearfix">
                    <label class="col-sm-3 control-label"><?php _e('Facebook', 'liberty'); ?></label>
                    
                    <div class="col-sm-4">
                    <input type="checkbox" name="facebook_opt" value="1" <?php echo (osc_get_preference('facebook_opt', 'liberty_theme') ? 'checked' : ''); ?>> Enable/Disable
                      <input type="text" class="form-control" name="lbt_facebook" value="<?php echo osc_esc_html( osc_get_preference('lbt_facebook', 'liberty_theme') ); ?>">
                      <small>Facebook Page Name. <a href="https://www.facebook.com/pages/create/" target="_blank">Get it here</a></small>
                    </div>
                </div><!--/ facebook-->
                
                <div class="form-group clearfix">
                    <label class="col-sm-3 control-label"><?php _e('Twitter', 'liberty'); ?></label>
                    <div class="col-sm-4">
                    <input type="checkbox" name="twitter_opt" value="1" <?php echo (osc_get_preference('twitter_opt', 'liberty_theme') ? 'checked' : ''); ?>> Enable/Disable
                      <input type="text" class="form-control" name="lbt_twitter" value="<?php echo osc_esc_html( osc_get_preference('lbt_twitter', 'liberty_theme') ); ?>">
                      <small>Twitter Profile Name. <a href="https://twitter.com/signup" target="_blank">Get it here</a></small>
                    </div>
                </div><!-- /twitter -->
                
                <div class="form-group clearfix">
                    <label class="col-sm-3 control-label"><?php _e('Google +', 'liberty'); ?></label>
                    <div class="col-sm-4">
                    	<input type="checkbox" name="google_opt" value="1" <?php echo (osc_get_preference('google_opt', 'liberty_theme') ? 'checked' : ''); ?>> Enable/Disable
                      <input type="text" class="form-control" name="lbt_googleplus" value="<?php echo osc_esc_html( osc_get_preference('lbt_googleplus', 'liberty_theme') ); ?>">
                      <small>Google+ Page Name. <a href="https://plus.google.com/pages/create" target="_blank">Get it here</a></small>
                    </div>
                </div><!-- /googleplus -->
                <div class="clearfix"></div>
                
        	</div><!--/panbody-->
    	</div><!--page/social end-->
        
        <div class="tab-pane" id="ico">
         	<div class="panel-body">
            
       			<h4>You can use <a target="_blank" rel="nofollow" href="http://fortawesome.github.io/Font-Awesome/icons/">FontAwesome Icons <i class="fa fa-external-link"></i></a> and <a target="_blank" rel="nofollow" href="http://getbootstrap.com/components/#glyphicons">Glyphicons <i class="fa fa-external-link"></i></a> and <a href="https://icomoon.io/#preview-free" rel="nofollow" target="_blank">IcoMoon<i class="fa fa-external-link"></i></a><br>
<small>Ex: <strong>fa fa-star</strong> or <strong>glyphicon glyphicon-star</strong> or <strong>icon icon-star</strong></small>

</h4>
           	<br />
       		<?php echo category_icons();?>
    		<div class="clearfix"></div>
            
          </div><!--/panbody-->
    	</div><!--caticons end-->
         
         <div class="tab-pane" id="wid">
         	<div class="panel-body">
            	<div class="form-group">
        			<label class="col-sm-3 control-label"><?php _e('Home page below the categories', 'liberty'); ?></label>
                    <div class="col-sm-4">
                    	<input type="checkbox" name="position1_enable" value="1" <?php echo (osc_get_preference('position1_enable', 'liberty_theme') ? 'checked' : ''); ?>> Enable or Disable
                        <input type="checkbox" name="position1_hide" value="1" <?php echo (osc_get_preference('position1_hide', 'liberty_theme') ? 'checked' : ''); ?>> Hide on Mobile view
                       <textarea class="form-control" rows="5" style="margin:10px 0 0 0;"  name="position1_content"><?php echo osc_get_preference('position1_content', 'liberty_theme', "UTF-8"); ?></textarea>
                        <small>HTML Supported</small>
                    </div>
        		</div><!-- field end -->
                <div class="clearfix"></div>
                <br />
                
                <div class="form-group">
        			<label class="col-sm-3 control-label"><?php _e('Home page below the latest listings', 'liberty'); ?></label>
                    <div class="col-sm-4">
                    	<input type="checkbox" name="position2_enable" value="1" <?php echo (osc_get_preference('position2_enable', 'liberty_theme') ? 'checked' : ''); ?>> Enable or Disable
                        <input type="checkbox" name="position2_hide" value="1" <?php echo (osc_get_preference('position2_hide', 'liberty_theme') ? 'checked' : ''); ?>> Hide on Mobile view
                       <textarea class="form-control" rows="5" style="margin:10px 0 0 0;"  name="position2_content"><?php echo osc_get_preference('position2_content', 'liberty_theme', "UTF-8"); ?></textarea>
                        <small>HTML Supported</small>
                    </div>
        		</div><!-- field end -->
                <div class="clearfix"></div>
                <br />
                
                <div class="form-group">
        			<label class="col-sm-3 control-label"><?php _e('Search page top of the listings', 'liberty'); ?></label>
                    <div class="col-sm-4">
                    	<input type="checkbox" name="position3_enable" value="1" <?php echo (osc_get_preference('position3_enable', 'liberty_theme') ? 'checked' : ''); ?>> Enable or Disable
                        <input type="checkbox" name="position3_hide" value="1" <?php echo (osc_get_preference('position3_hide', 'liberty_theme') ? 'checked' : ''); ?>> Hide on Mobile view
                       <textarea class="form-control" rows="5" style="margin:10px 0 0 0;"  name="position3_content"><?php echo osc_get_preference('position3_content', 'liberty_theme', "UTF-8"); ?></textarea>
                        <small>HTML Supported</small>
                    </div>
        		</div><!-- field end -->
                <div class="clearfix"></div>
                <br />
                
                <div class="form-group">
        			<label class="col-sm-3 control-label"><?php _e('Search page below of the listings', 'liberty'); ?></label>
                    <div class="col-sm-4">
                    	<input type="checkbox" name="position4_enable" value="1" <?php echo (osc_get_preference('position4_enable', 'liberty_theme') ? 'checked' : ''); ?>> Enable or Disable
                        <input type="checkbox" name="position4_hide" value="1" <?php echo (osc_get_preference('position4_hide', 'liberty_theme') ? 'checked' : ''); ?>> Hide on Mobile view
                       <textarea class="form-control" rows="5" style="margin:10px 0 0 0;"  name="position4_content"><?php echo osc_get_preference('position4_content', 'liberty_theme', "UTF-8"); ?></textarea>
                        <small>HTML Supported</small>
                    </div>
        		</div><!-- field end -->
                <div class="clearfix"></div>
                <br />
                
                 <div class="form-group">
        			<label class="col-sm-3 control-label"><?php _e('Item page before the comments', 'liberty'); ?></label>
                    <div class="col-sm-4">
                    	<input type="checkbox" name="position5_enable" value="1" <?php echo (osc_get_preference('position5_enable', 'liberty_theme') ? 'checked' : ''); ?>> Enable or Disable
                        <input type="checkbox" name="position5_hide" value="1" <?php echo (osc_get_preference('position5_hide', 'liberty_theme') ? 'checked' : ''); ?>> Hide on Mobile view
                       <textarea class="form-control" rows="5" style="margin:10px 0 0 0;"  name="position5_content"><?php echo osc_get_preference('position5_content', 'liberty_theme', "UTF-8"); ?></textarea>
                        <small>HTML Supported</small>
                    </div>
        		</div><!-- field end -->
                <div class="clearfix"></div>
                <br />
                
                 <div class="form-group">
        			<label class="col-sm-3 control-label"><?php _e('Item page below of the related listings', 'liberty'); ?></label>
                    <div class="col-sm-4">
                    	<input type="checkbox" name="position6_enable" value="1" <?php echo (osc_get_preference('position6_enable', 'liberty_theme') ? 'checked' : ''); ?>> Enable or Disable
                        <input type="checkbox" name="position6_hide" value="1" <?php echo (osc_get_preference('position6_hide', 'liberty_theme') ? 'checked' : ''); ?>> Hide on Mobile view
                       <textarea class="form-control" rows="5" style="margin:10px 0 0 0;"  name="position6_content"><?php echo osc_get_preference('position6_content', 'liberty_theme', "UTF-8"); ?></textarea>
                        <small>HTML Supported</small>
                    </div>
        		</div><!-- field end -->
                <div class="clearfix"></div>
                <br />
                
                <div class="form-group">
        			<label class="col-sm-3 control-label"><?php _e('Item post page before the creating a new ad', 'liberty'); ?></label>
                    <div class="col-sm-4">
                    	<input type="checkbox" name="position7_enable" value="1" <?php echo (osc_get_preference('position7_enable', 'liberty_theme') ? 'checked' : ''); ?>> Enable or Disable
                        <input type="checkbox" name="position7_hide" value="1" <?php echo (osc_get_preference('position7_hide', 'liberty_theme') ? 'checked' : ''); ?>> Hide on Mobile view
                       <textarea class="form-control" rows="5" style="margin:10px 0 0 0;"  name="position7_content"><?php echo osc_get_preference('position7_content', 'liberty_theme', "UTF-8"); ?></textarea>
                        <small>HTML Supported</small>
                    </div>
        		</div><!-- field end -->
                <div class="clearfix"></div>
                <br />
                
                <div class="form-group">
        			<label class="col-sm-3 control-label"><?php _e('Search sidebar', 'liberty'); ?></label>
                    <div class="col-sm-4">
                    	<input type="checkbox" name="position8_enable" value="1" <?php echo (osc_get_preference('position8_enable', 'liberty_theme') ? 'checked' : ''); ?>> Enable or Disable
                        <input type="checkbox" name="position8_hide" value="1" <?php echo (osc_get_preference('position8_hide', 'liberty_theme') ? 'checked' : ''); ?>> Hide on Mobile view
                       <textarea class="form-control" rows="5" style="margin:10px 0 0 0;"  name="position8_content"><?php echo osc_get_preference('position8_content', 'liberty_theme', "UTF-8"); ?></textarea>
                        <small>HTML Supported</small>
                    </div>
        		</div><!-- field end -->
                <div class="clearfix"></div>
                <br />
                
                <div class="form-group">
        			<label class="col-sm-3 control-label"><?php _e('Item sidebar', 'liberty'); ?></label>
                    <div class="col-sm-4">
                    	<input type="checkbox" name="position9_enable" value="1" <?php echo (osc_get_preference('position9_enable', 'liberty_theme') ? 'checked' : ''); ?>> Enable or Disable
                        <input type="checkbox" name="position9_hide" value="1" <?php echo (osc_get_preference('position9_hide', 'liberty_theme') ? 'checked' : ''); ?>> Hide on Mobile view
                       <textarea class="form-control" rows="5" style="margin:10px 0 0 0;"  name="position9_content"><?php echo osc_get_preference('position9_content', 'liberty_theme', "UTF-8"); ?></textarea>
                        <small>HTML Supported</small>
                    </div>
        		</div><!-- field end -->
                <div class="clearfix"></div>
                <br />
                
                <div class="form-group">
        			<label class="col-sm-3 control-label"><?php _e('User sidebar', 'liberty'); ?></label>
                    <div class="col-sm-4">
                    	<input type="checkbox" name="position10_enable" value="1" <?php echo (osc_get_preference('position10_enable', 'liberty_theme') ? 'checked' : ''); ?>> Enable or Disable
                        <input type="checkbox" name="position10_hide" value="1" <?php echo (osc_get_preference('position10_hide', 'liberty_theme') ? 'checked' : ''); ?>> Hide on Mobile view
                       <textarea class="form-control" rows="5" style="margin:10px 0 0 0;"  name="position10_content"><?php echo osc_get_preference('position10_content', 'liberty_theme', "UTF-8"); ?></textarea>
                        <small>HTML Supported</small>
                    </div>
        		</div><!-- field end -->
           	<div class="clearfix"></div>
          </div><!--/panbody-->
    	</div><!--widgets end-->
        
       	<div class="tab-pane" id="foo">
         	<div class="panel-body">
            
            	<div class="form-group">
        			<label class="col-sm-3 control-label"><?php _e('Footer Widget #1', 'liberty'); ?></label>
                    <div class="col-sm-4">
                    <input type="checkbox" name="widget_one" value="1" <?php echo (osc_get_preference('widget_one', 'liberty_theme') ? 'checked' : ''); ?>> Enable or Disable
                        <input type="text" class="form-control" name="widget1_title" value="<?php echo osc_esc_html( osc_get_preference('widget1_title', 'liberty_theme') ); ?>" />
                        <textarea class="form-control" rows="5" style="margin:10px 0 0 0;"  name="widget1_text"><?php echo osc_get_preference('widget1_text', 'liberty_theme', "UTF-8"); ?></textarea>
                        <small>HTML Supported</small>
                    </div>
        		</div><!-- /field end -->
        		<div class="clearfix"></div>
                <br />
                
        		<div class="form-group">
           			<label class="col-sm-3 control-label"><?php _e('Footer Widget #2', 'liberty'); ?></label>
            		<div class="col-sm-4">
                    	<input type="checkbox" name="widget_two" value="1" <?php echo (osc_get_preference('widget_two', 'liberty_theme') ? 'checked' : ''); ?>> Enable or Disable
            			<input type="text" class="form-control" name="widget2_title" value="<?php echo osc_esc_html( osc_get_preference('widget2_title', 'liberty_theme') ); ?>" />
                		<textarea class="form-control" rows="5" style="margin:10px 0 0 0;"  name="widget2_text"><?php echo osc_get_preference('widget2_text', 'liberty_theme', "UTF-8"); ?></textarea>
                		<small>HTML Supported</small>
            		</div>
        		</div><!-- /field end -->
                <div class="clearfix"></div>
       			
            <div class="clearfix"></div>
          </div><!--/panbody-->
    	</div><!--foo-widgets end-->
        

        
        <div class="tab-pane" id="plg">
         	<div class="panel-body">
            
            	<div class="col-md-10">
                <h4>Download Supported Plugins</h4>
                <br />
                <div class="mk-item mk-item-plugin pull-left">
    <div class="banner" style="background-image:url(http://demo.drizzlethemes.com/liberty/oc-admin/themes/modern/images/gr-g.png);">C</div>
    <div class="col-md-8 pull-right"><i class="flag"></i>        <h3>Custom attributes</h3>      
      <div class="market-actions">
        <a class="download-btn" href="<?php echo osc_current_web_theme_url('includes/custom_attributes.zip') ; ?>">Download</a>
      </div>
    </div>
  </div>
  <div class="mk-item mk-item-plugin pull-left">
    <div class="banner" style="background-image:url(http://demo.drizzlethemes.com/liberty/oc-admin/themes/modern/images/gr-b.png);">P</div>
    <div class="col-md-8 pull-right"><i class="flag"></i>        <h3>Profile Picture</h3>      
      <div class="market-actions">
        <a class="download-btn" href="<?php echo osc_current_web_theme_url('includes/profile_picture.zip') ; ?>">Download</a>
      </div>
    </div>
  </div>
  <div class="mk-item mk-item-plugin pull-left">
    <div class="banner" style="background-image:url(http://demo.drizzlethemes.com/liberty/oc-admin/themes/modern/images/gr-i.png);">W</div>
    <div class="col-md-8 pull-right"><i class="flag"></i>        <h3>Watchlist</h3>      
      <div class="market-actions">
        <a class="download-btn" href="<?php echo osc_current_web_theme_url('includes/watchlist.zip') ; ?>">Download</a>
      </div>
    </div>
  </div>
  
				</div>
        
    </div>
</div>
<style>
.download-btn {
  background-color: #2fbfd1;
  margin-left: 5px;
}
.mk-item {
  margin-right: 20px;
}
.download-btn {
  background-color: #2fbfd1;
  border-radius: 5px;
  color: #fff !important;
  margin-left: 5px;
  padding: 7px;
}
.market-actions {
  margin-top: 30px;
}
</style>
<!-- /tabs -->
      
<div class="form-actions">
	<div class="form-group">
       <div class="form-controls">
            <div class="form-label-checkbox"><input type="checkbox" name="footer_link" value="1" <?php echo (osc_get_preference('footer_link', 'liberty_theme') ? 'checked' : ''); ?> > <?php _e('I want to help Osclass by linking to <a href="http://osclass.org/" target="_blank">osclass.org</a> from my site with the following text:', 'liberty'); ?></div>
            <span class="help-box"><?php _e('This website is proudly using the <a title="Osclass web" href="http://osclass.org/">classifieds scripts</a> software <strong>Osclass</strong>', 'liberty'); ?></span>
        </div>
    </div>
      	<input type="submit" value="<?php _e('Save changes', 'liberty'); ?>" class="btn btn-primary">
      </div>
       </form>
 </div><!-- admin-tab-->
<div class="clearfix"></div>
<script type="text/javascript">
$('#content-head').empty().append("<h2>Liberty v.1.3.9</h2><span class='pull-right'><b><a href='www.drizzlethemes.com'>www.drizzlethemes.com</a></b></span>");
</script>