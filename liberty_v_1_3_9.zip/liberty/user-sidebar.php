

	
    <h4 class="box hidden-xs hidden-sm"><?php _e('My Dashboard','liberty'); ?></h4>
    	
   <div class="box">
    <h4><?php _e('User Menu','liberty'); ?></h4>
   <?php echo osc_private_user_menu( get_user_menu() ); ?>
    </div>
     <?php if (function_exists("profile_picture_upload")) { ?>
      <div class="box profile-pic">
      <h4><?php _e('Profile Picture','liberty'); ?></h4>
           <?php profile_picture_upload(); ?>
     </div>
     <?php }?>
    
<?php if( osc_get_preference('position10_enable', 'liberty_theme') != '0') { ?>
          			<div class="box <?php if( osc_get_preference('position1_hide', 'liberty_theme') != '0') {echo"hidden-xs hidden-sm";}?>">
              			<?php echo osc_get_preference('position10_content', 'liberty_theme', "UTF-8"); ?>
           			</div>
   		<?php } ?>
 <?php echo show_adsense(); ?>

<script type="text/javascript">
$(document).ready(function(){
$('.profile-pic #file').addClass("btn btn-primary");

});
</script>