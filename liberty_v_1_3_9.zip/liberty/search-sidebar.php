<?php
     $category = __get("category");
     if(!isset($category['pk_i_id']) ) {
         $category['pk_i_id'] = null;
     }
?>



<h4 class="box box hidden-xs hidden-sm"><?php _e('Advanced Search', 'liberty'); ?></h4>
 <form action="<?php echo osc_base_url(true); ?>" role="form" method="get" class="nocsrf">
        <input type="hidden" name="page" value="search"/>
        <input type="hidden" name="sOrder" value="<?php echo osc_search_order(); ?>" />
        <input type="hidden" name="iOrderType" value="<?php $allowedTypesForSorting = Search::getAllowedTypesForSorting() ; echo $allowedTypesForSorting[osc_search_order_type()]; ?>" />
        <input type="hidden" name="sPattern" id="query" placeholder="<?php echo osc_esc_html(__(osc_get_preference('keyword_placeholder', 'flatter_theme'), 'liberty')); ?>" value="<?php echo osc_esc_html(osc_search_pattern()); ?>" />
        
        <?php foreach(osc_search_user() as $userId) { ?>
        <input type="hidden" name="sUser[]" value="<?php echo $userId; ?>"/>
        <?php } ?>
        
		<?php if( osc_price_enabled_at_items() ) { ?> <!-------------- Refine By Price Input -------------------------------->
        <div class="form-group box">
        <h4 for="sPrice"><?php _e('Refine by Price', 'liberty'); ?></h4>
         <input class="pmin" type="text" id="priceMin" name="sPriceMin" placeholder="<?php _e('Min', 'liberty') ; ?>." value="<?php echo osc_esc_html(osc_search_price_min()); ?>" size="6" maxlength="6" />
                
                <input class="pmax pull-right" type="text" id="priceMax" name="sPriceMax" placeholder="<?php _e('Max', 'liberty') ; ?>." value="<?php echo osc_esc_html(osc_search_price_max()); ?>" size="6" maxlength="6" />
                
                 <br /><br />
              <button type="submit" class="pull-right btn btn-primary btn-md"><?php _e('Update', 'liberty') ; ?></button>
              <div class="clearfix"></div>
        </div>
         <?php } ?>
   

	
        
        
		<div class="form-group box"> <!-------------- Refine By Location -------------------------------->
        	<h4 for="sCity"><?php _e('Refine by Location', 'liberty'); ?></h4>
            <?php if(liberty_def_country() == 'r_c'){ ?>
          	  <?php echo location();?>
            <?php } else if(liberty_def_country() == 'c_r_c') { ?>
              <?php osc_current_web_theme_path('locationfind.php'); ?>
             <?php } else if(liberty_def_country() == 'country') { ?>
             <?php $conn = getConnection(); $aStates = $conn->osc_dbFetchResults("SELECT * FROM %st_country ", DB_TABLE_PREFIX); ?>
                <?php if (count($aStates) >= 0 ) { ?>
             <select id="countryId" name="sCountry" class="form-control">
                    <option value=""><?php _e("Select a country..."); ?></option>
                    <?php foreach($aStates as $state) { ?> 
                    <option <?php if(Params::getParam('sCountry') == $state['pk_c_code'] ) { ?>selected="selected"<?php } ?> value="<?php echo $state['pk_c_code']; ?>">
					
					<?php echo $state['s_name'] ; ?></option>
                    <?php } ?>
                </select>
             
                <?php } ?>
                
              <?php } else if(liberty_def_country() == 'region') { ?>
              				<?php // Regions
               					$aRegions = Region :: newInstance()->listAll(); ?>
                        		<?php if (count($aRegions) > 0) {?>
                       				<select class="form-control" name="sRegion" id="sRegion">
                        				<option value=""><?php _e("All Regions", 'liberty'); ?></option>
                        				<?php foreach ($aRegions as $regions) {?>
                        				<option <?php if(Params::getParam('sRegion') == $regions['s_name']) { ?>selected="selected"<?php } ?>  value="<?php echo $regions['s_name'];?>"><?php echo $regions['s_name'];?></option>
                						<?php } ?>
                					</select>
            					<?php } ?>
               <?php } else if(liberty_def_country() == 'city') { ?>
               					<?php // Regions
               					$aCities = City :: newInstance()->listAll(); ?>
                        		<?php if (count($aCities) > 0) {?>
                       				<select class="form-control" name="sCity" id="sCity">
                        				<option value=""><?php _e("All Cities", 'liberty'); ?></option>
                        				<?php foreach ($aCities as $cities) {?>
                        				<option <?php if(Params::getParam('sCity') == $cities['s_name']) { ?>selected="selected"<?php } ?>  value="<?php echo $cities['s_name'];?>"><?php echo $cities['s_name'];?></option>
                						<?php } ?>
                					</select>
            					<?php } ?>
               <?php } ?>
             
            <br /><br />
            <button type="submit" class="pull-right btn btn-primary btn-md"><?php _e('Update', 'liberty') ; ?></button>
            <div class="clearfix"></div>
        </div>
		
        
        <div class="plugin-hooks hidden-xs hidden-sm"> <!-------------- Custom Fields -------------------------------->
                <?php
                if(osc_search_category_id()) {
                    osc_run_hook('search_form', osc_search_category_id()) ;
                } else {
                    osc_run_hook('search_form') ;
                }
                ?>
          </div>
    	</form> 
        
      
       	<div class="form-group box hidden-xs hidden-sm"><!-------------- Refine By Category -------------------------------->
        	<h4><?php _e('Refine by category', 'liberty') ; ?></h4>
        	<div class="refine">
       		<?php liberty_sidebar_category_search($category['pk_i_id']); ?>
       		</div>
        </div>
        
        <?php if( osc_get_preference('position8_enable', 'liberty_theme') != '0') { ?>
          			<div class="box <?php if( osc_get_preference('position8_hide', 'liberty_theme') != '0') {echo"hidden-xs hidden-sm";}?>">
              			<?php echo osc_get_preference('position8_content', 'liberty_theme', "UTF-8"); ?>
           			</div>
   		<?php } ?>
        
       
       <?php echo show_adsense(); ?>

<script>
$(document).ready(function(){
$(".plugin-hooks fieldset").addClass("box");
	$('.plugin-hooks fieldset').append("<br /><br /><button type='submit' class='pull-right btn btn-primary btn-md'>Update</button><div class='clearfix'></div>");
});
</script>