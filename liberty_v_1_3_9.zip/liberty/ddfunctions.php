<?php //google adsense
function show_adsense() {
if( osc_get_preference('google_ad', 'liberty_theme') != '0') { ?>
	<div class="box"><!--------- Google ads -------->
   	<div class="ads-content">
    	<script type="text/javascript"><!--
        	google_ad_client = "ca-pub-<?php echo osc_esc_html( osc_get_preference('google_pub', 'liberty_theme') ); ?>";
            google_ad_slot = "9944415361";
           	google_ad_width = 270;
            google_ad_height = 200;
        </script>
        <script type="text/javascript" src="//pagead2.googlesyndication.com/pagead/show_ads.js"></script>
   	</div>
</div>
<?php } }?>
<?php /* Location Search*/
function location(){
			 $aRegions = Region::newInstance()->listAll();
                 if(count($aRegions) >= 0 ) { ?>
              
                <select id="regionId" name="sRegion" class="form-control">
                    <option value=""><?php _e("Select a region..."); ?></option>
                    <?php foreach($aRegions as $region) { ?>
                    <option id="idregioni"  value="<?php echo $region['pk_i_id']; ?>"<?php if(Params::getParam('sRegion') == $region['pk_i_id']) { ?>selected<?php } ?>><?php echo $region['s_name']; ?></option>
                    <?php } ?>
                </select>
               
                <?php } ?>
                 <br />
                <?php if (count($aCities) >= 0 ) {?>
                
                <select name="sCity" id="cityId" class="form-control"> 
                    <option value=""><?php _e("Select a city..."); ?></option>
                    <?php foreach($aCities as $city) { ?>      
                    <option value="<?php echo $city['pk_i_id']; ?>"<?php if(Params::getParam('sCity') == $city['pk_i_id']) { ?>selected<?php } ?>><?php echo $city['s_name'] ; ?></option>
                    <?php } ?>
                </select>
             
                <?php } ?> 
   


<script>
$(document).ready(function(){
	$("#countryId").live("change",function(){
		var pk_c_code = $(this).val();
		<?php if($path=="admin") { ?>
			var url = '<?php echo osc_admin_base_url(true)."?page=ajax&action=regions&countryId="; ?>' + pk_c_code;
		<?php } else { ?>
			var url = '<?php echo osc_base_url(true)."?page=ajax&action=regions&countryId="; ?>' + pk_c_code;
		<?php }; ?>
		var result = '';

		if(pk_c_code != '') {

			$("#regionId").attr('disabled',false);
			$("#cityId").attr('disabled',true);

			$.ajax({
				type: "POST",
				url: url,
				dataType: 'json',
				success: function(data){
					var length = data.length;
					
					if(length > 0) {

						result += '<option value=""><?php _e("Select a region..."); ?></option>';
						for(key in data) {
							result += '<option value="' + data[key].pk_i_id + '">' + data[key].s_name + '</option>';
						}

						$("#region").before('<select class="form-control" name="regionId" id="regionId" ></select>');
						$("#region").remove();

						$("#city").before('<select class="form-control" name="cityId" id="cityId" ></select>');
						$("#city").remove();
						
						$("#regionId").val("");

					} else {

						$("#regionId").before('<input class="form-control" placeholder="<?php _e("Enter region..."); ?>"type="text" name="region" id="region" />');
						$("#regionId").remove();
						
						$("#cityId").before('<input class="form-control" placeholder="<?php _e("Enter city..."); ?>" type="text" name="city" id="city" />');
						$("#cityId").remove();
						
					}

					$("#regionId").html(result);
					$("#cityId").html('<option selected value=""><?php _e("Select a city..."); ?></option>');
				}
			 });

		 } else {

			 // add empty select
			 $("#region").before('<select name="regionId" class="form-control" id="regionId" ><option value=""><?php _e("Select a region..."); ?></option></select>');
			 $("#region").remove();
			 
			 $("#city").before('<select name="cityId" class="form-control" id="cityId" ><option value=""><?php _e("Select a city..."); ?></option></select>');
			 $("#city").remove();

			 if( $("#regionId").length > 0 ){
				 $("#regionId").html('<option value=""><?php _e("Select a region..."); ?></option>');
			 } else {
				 $("#region").before('<select name="regionId" class="form-control" id="regionId" ><option value=""><?php _e("Select a region..."); ?></option></select>');
				 $("#region").remove();
			 }
			 if( $("#cityId").length > 0 ){
				 $("#cityId").html('<option value=""><?php _e("Select a city..."); ?></option>');
			 } else {
				 $("#city").before('<select name="cityId" class="form-control" id="cityId" ><option value=""><?php _e("Select a city..."); ?></option></select>');
				 $("#city").remove();
			 }
			 $("#regionId").attr('disabled',true);
			 $("#cityId").attr('disabled',true);
		 }
	});

	$("#regionId").live("change",function(){
		var pk_c_code = $(this).val();
		<?php if($path=="admin") { ?>
			var url = '<?php echo osc_admin_base_url(true)."?page=ajax&action=cities&regionId="; ?>' + pk_c_code;
		<?php } else { ?>
			var url = '<?php echo osc_base_url(true)."?page=ajax&action=cities&regionId="; ?>' + pk_c_code;
		<?php }; ?>

		var result = '';

		if(pk_c_code != '') {
			
			$("#cityId").attr('disabled',false);
			$.ajax({
				type: "POST",
				url: url,
				dataType: 'json',
				success: function(data){
					var length = data.length;
					if(length > 0) {
						result += '<option selected value=""><?php _e("Select a city..."); ?></option>';
						for(key in data) {
							result += '<option value="' + data[key].pk_i_id + '">' + data[key].s_name + '</option>';
						}

						$("#city").before('<select class="form-control" name="cityId" id="cityId" ></select>');
						$("#city").remove();
					} else {
						result += '<option value=""><?php _e('No results') ?></option>';
						$("#cityId").before('<input type="text" name="city" id="city" />');
						$("#cityId").remove();
					}
					$("#cityId").html(result);
				}
			 });
		 } else {
			$("#cityId").attr('disabled',true);
		 }
	});

	if( $("#regionId").attr('value') == "")  {
		$("#cityId").attr('disabled',true);
	}

	if($("#countryIds").length != 0) {
		if( $("#countryIds").attr('type').match(/select-one/) ) {
			if( $("#countryIds").attr('value') == "")  {
				$("#regionId").attr('disabled',true);
			}
		}
	}
});
</script>
<?php } ?>
<?php function responsive_recaptcha() {?>
<script type="text/javascript">
                         var RecaptchaOptions = {
                            theme : 'custom',
                            custom_theme_widget: 'responsive_recaptcha'
                         };
                         </script>
						<div id="responsive_recaptcha" style="display:none">
                    		<div id="recaptcha_image"></div>
                           	<div class="recaptcha_only_if_incorrect_sol" style="color:red">Incorrect please try again</div>
                    		<label class="solution">
                            	<span class="recaptcha_only_if_image">Type the two words:</span>
                            	<span class="recaptcha_only_if_audio">Enter the numbers you hear:</span>
                    			<input type="text" id="recaptcha_response_field" name="recaptcha_response_field" />
                         	</label>
                          	<div class="options">
                            	<a href="javascript:Recaptcha.reload()" id="icon-reload">Get another CAPTCHA</a>
                            	<a class="recaptcha_only_if_image" href="javascript:Recaptcha.switch_type('audio')" id="icon-audio">Get an audio CAPTCHA</a>
                            	<a class="recaptcha_only_if_audio" href="javascript:Recaptcha.switch_type('image')" id="icon-image">Get an image CAPTCHA</a>
                            	<a href="javascript:Recaptcha.showhelp()" id="icon-help">Help</a>
                          	</div>
                        </div>

<?php } ?>
<?php function cust_format_date_with_time($date, $dateformat = null) {
    if($dateformat==null) {
        $dateformat = osc_date_format();
    }
    $ampm = array('AM' => __('AM'), 'PM' => __('PM'), 'am' => __('am'), 'pm' => __('pm'));
    $time = strtotime($date);
    $dateformat = preg_replace('|(?<!\\\)A|', osc_escape_string($ampm[date('A', $time)]), $dateformat);
    $dateformat = preg_replace('|(?<!\\\)a|', osc_escape_string($ampm[date('a', $time)]), $dateformat);
    return date(osc_time_format(), $time);
}


function sidebar_premium() { ?>
<div class="box">
            		<h3>Premium ads</h3>
            		<div class="premium text-center">
						<div data-ride="carousel" class="carousel slide" id="carousel-example-generic">
            			<!-- Wrapper for slides -->
							<?php osc_get_premiums(5); ?>
							
            					<div class="carousel-inner">
                      				<?php while(osc_has_premiums()) { ?>
                        				<div class="item clearfix">
                          					<?php if( osc_images_enabled_at_items() ) { ?>
                          						<?php if(osc_count_premium_resources()) { ?>
                            						<a href="<?php echo osc_premium_url(); ?>"><img src="<?php echo osc_resource_thumbnail_url(); ?>" class="thumbnail clearfix" title="<?php echo osc_item_title(); ?>" alt="<?php echo osc_item_title(); ?>" /></a>
                          						<?php } else { ?>
                            						<a href="<?php echo osc_premium_url(); ?>"><img src="<?php echo osc_current_web_theme_url('img/no_photo.gif'); ?>" class="thumbnail clearfix" title="<?php echo osc_item_title(); ?>" alt="<?php echo osc_item_title(); ?>" /></a>
                            					<?php } ?>
                          					<?php } ?>
                          					<h4><a href="<?php echo osc_premium_url(); ?>"><?php echo osc_highlight( strip_tags( osc_premium_field('s_title') ), 30 ); ?></a></h4>
   											<p class="price"><?php if( osc_price_enabled_at_items() ) { ?> <?php echo osc_premium_formated_price(); ?> <?php } ?></p>
                            				<?php /*?><p><?php echo osc_highlight( strip_tags( osc_premium_description() ), 100 ); ?></p><?php */?>
                        				</div>
                        			<?php } ?>
                                </div>
                                <div class="clearfix"></div>
        					</div>
						</div>
            		</div>
<?php }?>