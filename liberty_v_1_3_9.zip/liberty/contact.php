<?php osc_add_hook('header','bender_nofollow_construct');

    liberty_add_body_class('contact');
    osc_enqueue_script('jquery-validate');
    osc_current_web_theme_path('header.php');
	
	 ?>
	
<section id="c-page">
    <div class="container">
		<div class="row">
       		<div class="col-md-12">
            
                    <div class=" box col-sm-8 col-sm-offset-2">
                     	<div class="col-md-12">
                      	<h3><?php _e('Contact us', 'liberty'); ?></h3>
                                <!--<ul id="error_list"></ul>-->
                                <form name="contact_form" action="<?php echo osc_base_url(true); ?>" method="post" >
                                    <input type="hidden" name="page" value="contact" />
                                    <input type="hidden" name="action" value="contact_post" />
                                   
                            <div class="col-md-6">
                                <?php ContactForm::your_name(); ?>
                            </div>
                           <div class="visible-xs visible-sm">
                            <div class="clearfix"></div>
                            <br>
                            </div>
                             <div class="col-md-6">
                                <?php ContactForm::your_email(); ?>
                            </div>
                            <div class="clearfix"></div>
                            
                               <br />
                             <div class="col-md-12">
                                <?php ContactForm::the_subject(); ?>
                            </div>
                            <div class="clearfix"></div>
                            
                             <br />
                             <div class="col-md-12">
                                 <?php ContactForm::your_message(); ?>
                            </div>
                            <div class="clearfix"></div>
                                  <br />
                             <div class="col-md-12">
                               <?php osc_run_hook('contact_form'); ?>
                              </div>
                              <div class="clearfix"></div>
                              
                              
                      <?php if( osc_recaptcha_items_enabled() ) { ?>
                      <div class="col-md-12">
                        <?php echo responsive_recaptcha(); ?>
                        <?php osc_show_recaptcha('register'); ?>
                         </div>
                            <div class="clearfix"></div>
                            <br />
                        <?php } ?>

                            
                            
                            
                            
                            
                            
                            
                               
                             <div class="col-md-12">   
                                 <button class="btn btn-success btn-lg col-md-12" type="submit"><?php _e("Send", 'liberty');?></button>
                               <?php osc_run_hook('admin_contact_form'); ?>
                            </div>
                            <div class="clearfix"></div>
                           
                                </form>
                                <?php ContactForm::js_validation(); ?>
                            </div>
                            <div class="clearfix"></div>
             			 </div>
                       
                         <div class="clearfix"></div>
                 </div>
           	</div>
         <div class="clearfix"></div>
     </div>
</section>   

<script type="text/javascript">
document.getElementById("yourName").setAttribute("placeholder","<?php _e("Name", 'liberty'); ?>")
document.getElementById("yourEmail").setAttribute("placeholder","<?php _e("Email address", 'liberty'); ?>")
document.getElementById("subject").setAttribute("placeholder","<?php _e("Subject", 'liberty'); ?>")
document.getElementById("message").setAttribute("placeholder","<?php _e("Message", 'liberty'); ?>")
</script>
    


<?php osc_current_web_theme_path('footer.php') ; ?>