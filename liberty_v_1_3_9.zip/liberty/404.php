<?php
    // meta tag robots
    osc_add_hook('header','liberty_nofollow_construct');
    liberty_add_body_class('error not-found');
    osc_current_web_theme_path('header.php') ;
?>
<section id="main-search">
	<div class="container">
		<div class="row">
        <div class="col-md-12 text-center infobar hidden-xs" id="search">
				<span class="info">
                <h2><?php _e("Page not found!", 'liberty') ; ?></h2>
					<p><?php _e("Sorry but I can't find the page you're looking for.", 'liberty') ; ?></p>
                	
                </span>
                 <div class="big-search">
					<form action="<?php echo osc_base_url(true); ?>" method="get" class="search nocsrf ser" <?php /* onsubmit="javascript:return doSearch();"*/ ?>>
        				<input type="hidden" name="page" value="search"/>
              			<span class="ser-item"><?php _e("I'm looking for", 'liberty'); ?></span>
                		<div class="custom-select ser-item">
               				<?php  if ( osc_count_categories() ) { ?>
				  				<?php osc_categories_select('sCategory', null, __('Somthings', 'liberty')); ?>
                			<?php } ?>
                		</div>
               			<span class="ser-item"> <?php _e("In", 'liberty'); ?> </span>
               			<div class="custom-select ser-item">
							<?php // Regions
               					$aRegions = Region :: newInstance()->listAll(); ?>
                        		<?php if (count($aRegions) > 0) {?>
                       				<select name="sRegion" id="sRegion">
                        				<option value=""><?php if (osc_has_countries()) {echo osc_country_name();}?><?php //_e("Uk", 'liberty'); ?></option>
                        				<?php foreach ($aRegions as $regions) {?>
                        				<option  value="<?php echo $regions['s_name'];?>"><?php echo $regions['s_name'];?></option>
                						<?php } ?>
                					</select>
            					<?php } ?>
               			</div>
                		<span class="ser-item">
        					<button type="submit" class="btn lib-primary"><?php _e("Go", 'liberty'); ?></button>
                        </span>
    				</form>
                </div><!--/big-search-->
  			</div>
        	<div class="clearfix"></div>
    	<?php echo liberty_draw_categories_list();?>	
			<div class="clearfix"></div>
        
        </div>
     </div>
</section>

<?php osc_current_web_theme_path('footer.php') ; ?>