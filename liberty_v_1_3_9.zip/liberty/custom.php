<?php
osc_add_hook('header','flatter_nofollow_construct');

liberty_add_body_class('userpage user-custom custom');
osc_add_hook('before-main','sidebar');
function sidebar(){
	osc_current_web_theme_path('user-sidebar.php');
}
osc_current_web_theme_path('header.php') ;
?>
<section id="custom">
	<div class="container">
    	<div class="row">
        	<div class="col-md-3 hidden-xs hidden-sm">
            	<?php osc_run_hook('before-main'); ?>
            </div>
            <div class="col-md-9">
            	<div class="box">
            		<?php osc_render_file(); ?>
                </div>
            </div>
            <div class="col-md-3 visible-xs visible-sm">
            	<?php osc_run_hook('before-main'); ?>
            </div>
		</div>
	</div>
</section>
<?php osc_current_web_theme_path('footer.php') ; ?>