<div class="col-xs-12 col-sm-4 item-block top-premium">
	<div class="item-container clearfix">
    
    <div class="col-md-3 col-sm-3 col-xs-12"><!---- Image Column ------>
        <div class="image-column">
            <?php if( osc_images_enabled_at_items() ) { ?>
                <?php if(osc_count_premium_resources()) { ?>
                        <a class="item-image" href="<?php echo osc_premium_url() ; ?>" title="<?php echo osc_premium_title() ; ?>"><img src="<?php echo osc_resource_thumbnail_url(); ?>" title="<?php echo osc_premium_title() ; ?>" alt="<?php echo osc_premium_title() ; ?>" class="img-responsive"></a>
                <?php } else { ?>
                    	<a class="item-image no_image" href="<?php echo osc_premium_url() ; ?>" title="<?php echo osc_premium_title() ; ?>"><img src="<?php echo osc_current_web_theme_url('images/no_photo.gif'); ?>" title="<?php echo osc_premium_title() ; ?>" alt="<?php echo osc_premium_title() ; ?>" class="img-responsive"></a>
                <?php } ?>
            <?php } ?>
        </div>
        </div>
	
    <div class="col-md-6 col-sm-6 g-title"><!---- Title Descriptions------>
        <div class="item-column">
              <div class="gallery-title">
            <a href="<?php echo osc_premium_url() ; ?>" class="title" title="<?php echo osc_premium_title() ; ?>"><?php echo osc_highlight( strip_tags( osc_premium_title() ), 40 ); ?></a>
        </div>
        
     
        <!---- Date and time------>
        <div class="meta"><p><small>
             <?php
		$date = osc_item_field("dt_pub_date");
		$yesterday = 172800;
		$today = 86400;
		$time = strtotime($date);
		$time = time()-$time;
		
		if ($today > $time) {echo 'Today';}
		else if ($yesterday > $time && $yesterday > $today) {echo 'Yesterday';}
		else if ($time> $yesterday) {echo osc_format_date(osc_premium_pub_date());}
		
		?>  <?php _e('at', 'liberty'); ?> <?php echo cust_format_date_with_time(osc_premium_pub_date()); ?> - <?php echo osc_premium_contact_name();?></small></p></div>
          
            <p class="description-search hidden-xs"><small><?php echo osc_highlight( strip_tags( osc_premium_description()), 110) ; ?></small></p><!----Descriptions------>
            
              <?php if($admin){ ?><!---- Admin Options------>
  <div class="admin-options">
   	<small><a href="<?php echo osc_item_edit_url(); ?>" rel="nofollow"><i class="fa fa-pencil-square-o"></i>&nbsp;<?php _e('Edit item', 'liberty'); ?></a>
    <span>|</span>
    <a class="delete" onclick="javascript:return confirm('<?php echo osc_esc_js(__('This action can not be undone. Are you sure you want to continue?', 'liberty')); ?>')" href="<?php echo osc_item_delete_url();?>" ><i class="fa fa-times-circle"></i>&nbsp;<?php _e('Delete', 'liberty'); ?></a></small>
    <?php if(osc_item_is_inactive()) {?>
    <small><span>|</span>
    <a href="<?php echo osc_item_activate_url();?>" ><?php _e('Activate', 'liberty'); ?></a></small>
    <?php } ?>
  </div>
  <?php } ?>
            
            
            <p class="visible-xs"><!---- Price For Mobile View------>
			   <?php if (osc_premium_price()=="0") {?> <?php _e('Check with seller', 'liberty'); ?> <?php } else { ?>
				<span class="price"><?php echo osc_format_price(osc_premium_price()); ?> <?php echo osc_premium_currency_symbol();?></span>
				<?php }?></p>
        </div>
      </div>
        
      <div class="price-column pull-right hidden-xs"><!---- Price Column------>
    
        <?php if (osc_premium_price()=="0") {?> <?php _e('Check with seller', 'liberty'); ?> <?php } else { ?>
				<p><span class="price"><?php echo osc_format_price(osc_premium_price()); ?> <?php echo osc_premium_currency_symbol();?></span></p>
				<?php }?>
            
       <p><span class="views"><small><?php echo osc_premium_views(); ?> <?php _e('Views', 'liberty'); ?></small></span></p>
       <p><span class="watchlist-search"><small><?php echo osc_premium_city(); ?></small></span></p>
       
       
       <div class="hot"><a href="<?php echo osc_premium_url() ; ?>"><i class="fa fa-hand-o-left pull-left"></i><?php echo osc_esc_html( osc_get_preference('premium_text', 'liberty_theme') ); ?></a></div>
  
   </div>
   

</div>
</div>


<style>
.listing-card-list.premium-list > div {
  background: none repeat scroll 0 0 #fef3d3;
  border: 1px solid #fedf8f;
}
</style>


