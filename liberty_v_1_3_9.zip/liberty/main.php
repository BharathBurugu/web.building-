<?php osc_current_web_theme_path('header.php') ; ?>
 <?php if( osc_get_preference('pop_enable', 'liberty_theme') != '0') { ?>
<!-- Modal -->
<div class="modal fade" id="promo" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
            	<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
       </div>
      <div class="modal-body">
      <?php echo osc_get_preference('landing_pop', 'liberty_theme', "UTF-8"); ?>
      </div>
      
    </div>
  </div>
</div>
 <?php if( osc_get_preference('pop_once', 'liberty_theme') != '1') { ?>
<script type="text/javascript">
    $(window).load(function(){
        $('#promo').modal('show');
    });
</script>
<?php } else { ?>
<script src="<?php echo osc_current_web_theme_url('js/jquery.cookie.min.js') ; ?>"></script>
<script type="text/javascript">
 $(window).load(function(){
     if ($.cookie('pop') == null) {
         $('#promo').modal('show');
         $.cookie('pop', '1');
     }
 });
</script>
<?php }?>
<?php }?>




<section id="main-search">
	<div class="container">
		<div class="row">
			<div class="col-md-12 hidden-sm text-center infobar hidden-xs" id="search"><!-----------------Main Big Search-------------------------->
				<span class="info">
                	<h2><?php echo osc_esc_html(__(osc_get_preference('welcome_text', 'liberty_theme'), 'liberty')); ?></h2>
                   
                    
                </span>
                 <div class="big-search">
					<form action="<?php echo osc_base_url(true); ?>" method="get" class="search nocsrf ser" <?php /* onsubmit="javascript:return doSearch();"*/ ?>>
        				<input type="hidden" name="page" value="search"/>
              			<span class="ser-item"><?php _e("I'm looking for", 'liberty'); ?></span>
                		<div class="custom-select ser-item">
               				<?php  if ( osc_count_categories() ) { ?>
				  				<?php osc_categories_select('sCategory', null, __('Something', 'liberty')); ?>
                			<?php } ?>
                		</div>
               			<span class="ser-item"> <?php _e("In", 'liberty'); ?> </span>
               			<div class="custom-select ser-item">
							<?php // Regions
               					$aRegions = Region :: newInstance()->listAll(); ?>
                        		<?php if (count($aRegions) > 0) {?>
                       				<select name="sRegion" id="sRegion">
                        				<option value=""><?php if (osc_has_countries()) {echo osc_country_name();}?><?php //_e("Uk", 'liberty'); ?></option>
                        				<?php foreach ($aRegions as $regions) {?>
                        				<option  value="<?php echo $regions['s_name'];?>"><?php echo $regions['s_name'];?></option>
                						<?php } ?>
                					</select>
            					<?php } ?>
               			</div>
                		<span class="ser-item">
        					<button type="submit" class="btn lib-primary"><?php _e("Go", 'liberty'); ?></button>
                        </span>
    				</form>
                </div><!--/big-search-->
  			</div>
          </div>
     </div>
</section>


<section id="pop-premium">
	<div class="container">
		<div class="row">
            <div class="col-md-12 col-xs-12">
            	<div class="box categories">
            		<h2><?php _e("Categories", 'liberty'); ?></h2><!------ Category Icons--------------------->
                    	<div class="m-cat">
                    		<ul>
                       			<?php	$i = 0; while ( osc_has_categories() ) { ?>
                   					
                                    <li>
                 						<a class="category <?php echo osc_category_slug(); ?>" href="<?php echo osc_search_category_url(); ?>">
										<i class="<?php echo osc_esc_html( osc_get_preference('cat_icon_'.osc_category_id(), 'liberty_theme') ); ?>"></i>
										<?php echo osc_category_name(); ?>
                                        </a>
          							</li>
        						<?php $i++; }  ?>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                        
                        
    				</div>
				</div>
       
		</div>
	</div>
</section>

<?php if( osc_get_preference('position1_enable', 'liberty_theme') != '0') { ?>
<section id="position_1"><!------ Home page widget 1--------------------->
	<div class="container">
		<div class="row">
            <div class="col-md-12 col-xs-12">
            	<div class="box position_1 <?php if( osc_get_preference('position1_hide', 'liberty_theme') != '0') {echo"hidden-xs";}?> ">
               		<?php echo osc_get_preference('position1_content', 'liberty_theme', "UTF-8"); ?>
            	</div>
			</div>
       	</div>
	</div>
</section>
<?php } ?>

<section id="latest">
	<div class="container">
		<div class="row">
        	<div class="col-md-12">
            <div class="box latestitem"><!-------------- Latest Listings---------------------------->
                <h2><?php _e('Latest Listings', 'liberty'); ?></h2>
   				<?php if( osc_count_latest_items() == 0) { ?>
    				<p class="empty"><?php _e("There aren't listings available at this moment", 'liberty'); ?></p>
    			<?php } else { ?>
    				<?php while ( osc_has_latest_items() ) { ?>
        				<div class="l-item col-lg-3 col-xs-6 col-md-3 col-sm-4 text-center">
                            <div class="item-container clearfix">
            					<?php if( osc_count_item_resources() ) { ?>
            						<div class="image-column">
            							<a href="<?php echo osc_item_url(); ?>">
            								<img src="<?php echo osc_resource_thumbnail_url(); ?>" class="thumbnail clearfix" title="<?php echo osc_item_title(); ?>" alt="<?php echo osc_item_title(); ?>" />
            							</a>
            						</div>
            					<?php } else { ?>
            						<div class="image-column">
            							<a href="<?php echo osc_item_url(); ?>">
            								<img src="<?php echo osc_current_web_theme_url('images/no_photo.gif'); ?>" class="thumbnail no-image clearfix" alt="<?php echo osc_item_title(); ?>" title="<?php echo osc_item_title(); ?>" />
                                        </a>
            						</div>
            					<?php } ?>
            						<div class="item-column">
            							<h4><a href="<?php echo osc_item_url(); ?>"><?php echo osc_highlight( strip_tags( osc_item_title() ), 40 ); ?></a></h4>
            							<p><span class="price"><?php if( osc_price_enabled_at_items() ) echo osc_item_formated_price(); ?></span></p>
            						</div>
        						</div>
        					</div>
       					<?php } ?>
   					<?php } ?>
   					<div class="clearfix"></div>
    			</div>
			</div>
		</div>
	</div>
</section>

<?php if( osc_get_preference('position2_enable', 'liberty_theme') != '0') { ?>
<section id="position_1"><!------ Home page widget 2--------------------->
	<div class="container">
		<div class="row">
            <div class="col-md-12 col-xs-12">
            	<div class="box position_2 <?php if( osc_get_preference('position1_hide', 'liberty_theme') != '0') {echo"hidden-xs";}?>">
               		<?php echo osc_get_preference('position2_content', 'liberty_theme', "UTF-8"); ?>
            	</div>
			</div>
       	</div>
	</div>
</section>
<?php } ?>
<?php osc_current_web_theme_path('footer.php') ; ?>