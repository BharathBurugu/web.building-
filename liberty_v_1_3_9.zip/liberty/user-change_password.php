<?php
	// meta tag robots
    osc_add_hook('header','liberty_nofollow_construct');

    liberty_add_body_class('user user-profile');
   // osc_add_hook('before-main','sidebar');
   // function sidebar(){
    //    osc_current_web_theme_path('user-sidebar.php');
   // }
    osc_add_filter('meta_title_filter','custom_meta_title');
    function custom_meta_title($data){
        return __('Change password', 'liberty');;
    }
    osc_current_web_theme_path('header.php') ;
    $osc_user = osc_user();
?>
<section id="myaccount">
    <div class="container">
		<div class="row">
        	<div class="col-md-3 hidden-xs hidden-sm">
            	<?php echo osc_current_web_theme_path('user-sidebar.php');?>
            </div>
           	<div class="col-md-9">
           		<div class="box">
                <?php UserForm::location_javascript(); ?>
                    	<h3><?php _e('Change password', 'liberty'); ?></h3>
    	<div class="inner-wrapper">
        <ul id="error_list"></ul>
  		<form action="<?php echo osc_base_url(true); ?>" class="form-horizontal" role="form"  method="post">
            <input type="hidden" name="page" value="user" />
            <input type="hidden" name="action" value="change_password_post" />
            <div class="form-group">
                <label for="password" class="col-sm-3 control-label"><?php _e('Current password', 'liberty'); ?></label>
                <div class="col-sm-5">
                  <input type="password" class="form-control" name="password" id="password" value="" />
                </div>
            </div>
            <div class="form-group">
                <label for="new_password" class="col-sm-3 control-label"><?php _e('New password', 'liberty'); ?></label>
                <div class="col-sm-5">
                  <input type="password" class="form-control" name="new_password" id="new_password" value="" />
                </div>
            </div>
            <div class="form-group">
                <label for="new_password2" class="col-sm-3 control-label"><?php _e('Repeat new password', 'liberty'); ?></label>
                <div class="col-sm-5">
                  <input type="password" name="new_password2" id="new_password2" value="" />
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-5">
                  <button type="submit" class="btn btn-primary"><?php _e("Update", 'liberty'); ?></button>
                </div>
            </div>
        </form>
                </div>
            </div>
        </div>
        <div class="col-md-3 visible-xs visible-sm">
            	<?php echo osc_current_web_theme_path('user-sidebar.php');?>
            </div>
     	</div>
    </div>
</section>
<?php osc_current_web_theme_path('footer.php') ; ?>