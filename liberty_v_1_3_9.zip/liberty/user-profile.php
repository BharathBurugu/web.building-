<?php
	// meta tag robots
    osc_add_hook('header','liberty_nofollow_construct');

    liberty_add_body_class('user user-profile');
    //osc_add_hook('before-main','sidebar');
    //function sidebar(){
     //   osc_current_web_theme_path('user-sidebar.php');
   // }
    osc_add_filter('meta_title_filter','custom_meta_title');
    function custom_meta_title($data){
        return __('Update account', 'liberty');
    }
    osc_current_web_theme_path('header.php') ;
    $osc_user = osc_user();
?>
<section id="myaccount">
    <div class="container">
		<div class="row">
        	<div class="col-md-3 hidden-xs hidden-sm">
            	<?php echo osc_current_web_theme_path('user-sidebar.php');?>
            </div>
           	<div class="col-md-9">
           		<div class="box">
                <?php UserForm::location_javascript(); ?>
                    	<h3><?php _e('Update account', 'liberty'); ?></h3>
    	<div class="inner-wrapper">
        <ul id="error_list"></ul>
        <form action="<?php echo osc_base_url(true); ?>" class="form-horizontal" role="form" method="post">
            <input type="hidden" name="page" value="user" />
            <input type="hidden" name="action" value="profile_post" />
            <div class="form-group">
                <label for="name" class="col-sm-2 control-label"><?php _e('Name', 'liberty'); ?></label>
                <div class="col-sm-5">
                  <?php UserForm::name_text(osc_user()); ?>
                </div>
            </div>
            <div class="form-group">
                <label for="user_type" class="col-sm-2 control-label"><?php _e('User type', 'liberty'); ?></label>
                <div class="col-sm-5">
                  <?php UserForm::is_company_select(osc_user()); ?>
                </div>
            </div>
            <div class="form-group">
                <label for="phoneMobile" class="col-sm-2 control-label"><?php _e('Mobile', 'liberty'); ?></label>
                <div class="col-sm-5">
                  <?php UserForm::mobile_text(osc_user()); ?>
                </div>
            </div>
            <div class="form-group">
                <label for="phoneLand" class="col-sm-2 control-label"><?php _e('Phone', 'liberty'); ?></label>
                <div class="col-sm-5">
                  <?php UserForm::phone_land_text(osc_user()); ?>
                </div>
            </div>
            <div class="form-group">
                <label for="country" class="col-sm-2 control-label"><?php _e('Country', 'liberty'); ?></label>
                <div class="col-sm-5">
                  <?php UserForm::country_select(osc_get_countries(), osc_user()); ?>
                </div>
            </div>
            <div class="form-group">
                <label for="region" class="col-sm-2 control-label"><?php _e('Region', 'liberty'); ?></label>
                <div class="col-sm-5">
                  <?php UserForm::region_select(osc_get_regions(), osc_user()); ?>
                </div>
            </div>
            <div class="form-group">
                <label for="city" class="col-sm-2 control-label"><?php _e('City', 'liberty'); ?></label>
                <div class="col-sm-5">
                  <?php UserForm::city_select(osc_get_cities(), osc_user()); ?>
                  <?php //UserForm::city_text(osc_get_cities(), osc_user()); ?>
                </div>
            </div>
            <div class="form-group">
                <label for="address" class="col-sm-2 control-label"><?php _e('Address', 'liberty'); ?></label>
                <div class="col-sm-5">
                  <?php UserForm::address_text(osc_user()); ?>
                </div>
            </div>
            <div class="form-group">
                <label for="webSite" class="col-sm-2 control-label"><?php _e('Website', 'liberty'); ?></label>
                <div class="col-sm-5">
                  <?php UserForm::website_text(osc_user()); ?>
                </div>
            </div>
            <div class="form-group">
                <label for="s_info" class="col-sm-2 control-label"><?php _e('Description', 'liberty'); ?></label>
                <div class="col-sm-5">
                  <?php UserForm::info_textarea('s_info', osc_locale_code(), @$osc_user['locale'][osc_locale_code()]['s_info']); ?>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-5">
                    <?php osc_run_hook('user_form', osc_user()); ?>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-5">
                  <button type="submit" class="btn btn-primary pull-right"><?php _e("Update", 'liberty'); ?></button>
                </div>
            </div>
        </form>
                </div>
            </div>
        </div>
        <div class="col-md-3 visible-xs visible-sm">
            	<?php echo osc_current_web_theme_path('user-sidebar.php');?>
            </div>
     </div>
</section>
<?php osc_current_web_theme_path('footer.php') ; ?>