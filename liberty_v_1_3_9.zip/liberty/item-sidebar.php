<section id="sidebar">

    <?php if( osc_count_item_meta() >= 1 ) { ?><!--------- Custom Fields ------>
	<div id="item-fields" class="cmeta box">
    	<h3><?php _e("Additional Details", 'liberty'); ?></h3>
        <div class="cmeta-empty"><?php while ( osc_has_item_meta() ) { ?><?php if(osc_item_meta_value()!='') { ?><p><span><?php echo osc_item_meta_name(); ?>:</span> <?php echo osc_item_meta_value(); ?></p><?php } ?><?php } ?></div>
      </div>
<?php } ?>
          <!-- Custom attributes-->              
	<div class="att box"><?php osc_run_hook('item_detail', osc_item() ); ?></div>
    <div class="box"><!---------- Seller Details -------------->
    	<h3><?php _e("Seller Details", 'liberty'); ?></h3>
      	<div class="sellerdetails">
        	<div class="col-md-4 profile">
            	<?php if (function_exists("profile_picture_show")) { ?>
                        <?php profile_picture_show(); ?>
                    <?php } else { ?>
                <img src="http://www.gravatar.com/avatar/<?php echo md5( strtolower( trim( osc_logged_user_email() ) ) ); ?>?s=60">
                <?php } ?>
            </div>
            
            <div class="col-md-8">
            	<?php if( osc_item_user_id() != null ) { ?>
            	<p class="name"><a href="<?php echo osc_user_public_profile_url( osc_item_user_id() ); ?>" ><?php echo osc_item_contact_name(); ?></a></p>
               	<?php } else { ?>
             	<?php echo osc_item_contact_name(); ?>
                <?php } ?>
                <?php if( osc_item_show_email() ) { ?>
               	<p class="email" style="word-break:break-word;"><?php echo osc_item_contact_email(); ?></p>
                <?php } ?>
                <?php if ( osc_user_phone() != '' ) { ?>
                <p class="phone"><?php echo osc_user_phone(); ?></p>
             	<?php } ?>
             </div>
		</div>
		<div class="clearfix"></div>
        
        <div class="widget-content"><!------------- Clontact Publisher ----------->
			<?php if( osc_item_is_expired () ) { ?>
        	<p class="login-only"><?php _e("The listing is expired. You can't contact the publisher.", 'liberty'); ?></p>
           	<?php } else if( ( osc_logged_user_id() == osc_item_user_id() ) && osc_logged_user_id() != 0 ) { ?>
           	<p class="login-only"><?php _e("It's your own listing, you can't contact the publisher.", 'liberty'); ?></p>
            <?php } else if( osc_reg_user_can_contact() && !osc_is_web_user_logged_in() ) { ?>
            <p class="login-only"><?php _e("You must log in or register a new account in order to contact the advertiser", 'liberty'); ?></p>
            <p class="contact_button">
            	<strong><a class="btn btn-primary pull-right" href="<?php echo osc_user_login_url(); ?>"><?php _e('Login', 'liberty'); ?></a></strong>
                <?php /*?><strong><a href="<?php echo osc_register_account_url(); ?>"><?php _e('Register for a free account', 'liberty'); ?></a></strong><?php */?>
          	</p>
            <?php } else { ?>
            <?php //seller_post(); ?>
            <ul id="error_list"></ul>
            <form action="<?php echo osc_base_url(true); ?>" runat="form" method="post" name="contact_form" id="contact_form" <?php if(osc_item_attachment()) { echo 'enctype="multipart/form-data"'; };?> >
           		<?php osc_prepare_user_info(); ?>
           		<input type="hidden" name="action" value="contact_post" />
                <input type="hidden" name="page" value="item" />
                <input type="hidden" name="id" value="<?php echo osc_item_id(); ?>" />
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user"></i></span>
                  <input type="text" value="<?php echo osc_logged_user_name() ; ?>" name="yourName" id="yourName" class="form-control" placeholder="<?php _e('Your name', 'liberty'); ?>">
                </div>
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                  <input type="text" value="<?php echo osc_logged_user_email() ; ?>" name="yourEmail" id="yourEmail" class="form-control" placeholder="<?php _e('Your e-mail address', 'liberty'); ?>">
                </div>
               	<div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-phone-square"></i></span>
                  <input type="text" value="" name="phoneNumber" id="phoneNumber" class="form-control" placeholder="<?php _e('Phone number', 'liberty'); ?>">
                </div>
                <?php if(osc_item_attachment()) { ?>
                <div class="input-group">
                  <?php ContactForm::your_attachment() ; ?>
                </div>
                <?php } ?>
               	<div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-comment"></i></span>
                  <textarea class="form-control" rows="3" name="message" id="message" placeholder="<?php _e('Your message or question', 'liberty'); ?>"></textarea>
                </div>
				<?php osc_run_hook('item_contact_form', osc_item_id()); ?>
               	<?php if( osc_recaptcha_public_key() ) { ?>
                <div class="input-group">
					<script type="text/javascript">
                        var RecaptchaOptions = {
                            theme : 'custom',
                            custom_theme_widget: 'recaptcha_widget'
                        };
                    </script>
                   	<div id="recaptcha_widget">
                    	<div id="recaptcha_image"><img /></div>
                        <span class="recaptcha_only_if_image"><?php _e('Enter the words above','liberty'); ?>:</span>
                        <input type="text" class="form-control" id="recaptcha_response_field" name="recaptcha_response_field" />
                    </div>
               		<?php osc_show_recaptcha(); ?>
                </div>
                <?php } ?>
                <button class="btn btn-primary full pull-right" type="submit"><?php _e("Send", 'liberty');?></button>
               	<br/>
            </form>
        	<?php } ?>
            
            <br />
            <hr/>
            <div style="padding-bottom: 0px;" class="safty-tips clearfix"><!------------ Safety Tips ------------------>
                <h4><?php _e('Safety Tips for Buyers','liberty'); ?></h4>
                <ol class="bullet-list">
                <li><?php _e('Meet seller at a safe location','liberty'); ?></li>
                <li><?php _e('Check the item before you buy','liberty'); ?></li>
                <li><?php _e('Pay only after collecting the item','liberty'); ?></li>
                </ol>
			</div>
        </div>
	</div><!---end seller Details-->
    <?php if( osc_get_preference('position9_enable', 'liberty_theme') != '0') { ?>
          			<div class="box <?php if( osc_get_preference('position9_hide', 'liberty_theme') != '0') {echo"hidden-xs hidden-sm";}?>">
              			<?php echo osc_get_preference('position9_content', 'liberty_theme', "UTF-8"); ?>
           			</div>
   		<?php } ?>
    <?php echo show_adsense(); ?>
</section><!-- /sidebar -->

