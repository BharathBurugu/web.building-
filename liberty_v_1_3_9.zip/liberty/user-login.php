<?php
// meta tag robots

    osc_add_hook('header','liberty_nofollow_construct');
    liberty_add_body_class('login');

	osc_enqueue_script('jquery-validate');
    osc_current_web_theme_path('header.php'); ?>

<section id="login">
    <div class="container">
    	<div class="row">
        	<div class="col-md-12">
        		<div class="box">
            		<div class="col-md-6 col-lg-6 col-sm-12 col-xs-12 first"><h3><?php _e('Sign in below', 'liberty'); ?> - <small><?php _e('Welcome back', 'liberty'); ?>.</small></h3>
                    	<form action="<?php echo osc_base_url(true); ?>" class="form-horizontal" role="form" method="post" >
                    		<input type="hidden" name="page" value="login" />
                            <input type="hidden" name="action" value="login_post" />
                            
                            <div class="col-md-12">
                            	<?php UserForm::email_login_text(); ?>
                            </div>
                            <div class="clearfix"></div>
                            <br>
                            
                            
                            <div class="col-md-12">
                            	<?php UserForm::password_login_text(); ?>
                            </div>
                            <div class="clearfix"></div>
                            <br />
                            
                            
                            <div class="col-md-6 col-xs-6">
                                <div class="checkbox">
                                    <?php UserForm::rememberme_login_checkbox(); ?> 
                                    <h4><small><?php _e('Stay signed in', 'liberty'); ?></small></h4>
                                </div>
                            </div>
                            
                            
                            <div class="col-md-6 col-xs-6 text-right">              
                                <h4><a href="<?php echo osc_recover_user_password_url(); ?>"><small><?php _e("Forgot password?", 'liberty'); ?></small></a></h4>
                            </div>
                            <div class="clearfix"></div>
                            <br>
                            
                            
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-success btn-lg col-xs-12 col-md-12"><?php _e("Sign in", 'liberty'); ?></button>
                            </div>
                            
                            <?php if (function_exists("fbc_button")) { ?>
                            <br />
                            <div class="col-md-12 fb-button">
                            <?php fbc_button(); ?>
                     		</div>
                            <?php } ?>
                            <div class="clearfix"></div>
                            <br />
                            
                            
                             <h4 class="text-center visible-xs visible-sm"><a href="<?php echo osc_recover_user_password_url(); ?>"><small>
                             <?php _e("Don't have an account?", 'liberty'); ?></small></a> <a href="<?php echo osc_register_account_url(); ?>"><?php _e('Create an account', 'liberty'); ?></small></a></h4>
                        </form>
                    
                   
                    <div class="clearfix"></div>
                    </div><!------------- End Login ----------------->
                    

                    <div class="col-md-6 hidden-xs hidden-sm"><!------------- Start Register Form -------------------->
                        <form name="register" action="<?php echo osc_base_url(true); ?>" class="form-horizontal" role="form" method="post" >
                        	<input type="hidden" name="page" value="register" />
                        	<input type="hidden" name="action" value="register_post" />
                        	<h3><?php _e('Sign Up', 'liberty'); ?> <small>- <?php _e("It's free! No obligations", "liberty"); ?>.</small></h3>
                            
                            
                    		<div class="col-md-6">
                            	<?php UserForm::name_text(); ?>
                            </div>
                            
                            <div class="col-md-6">
                            	<?php UserForm::email_text(); ?>
                            </div>
                            <div class="clearfix"></div>
                            <br>
                            
                            <div class="col-md-12">
                            	<?php UserForm::password_text(); ?>
                            </div>
                            <div class="clearfix"></div>
                            <br>
                            
                            <div class="col-md-12">
                            	<?php UserForm::check_password_text(); ?>
                            </div>
                            <div class="clearfix"></div>
                            <br>
                            
                            <div class="col-md-12">
                            	<?php UserForm::phone_land_text(); ?>
                            </div>
                            <div class="clearfix"></div>
                            <br>
                            
                            <div class="col-md-12">
                            	<?php UserForm::website_text(); ?>
                            </div>
                            <div class="clearfix"></div>
                            <br>
                            
                            <div class="col-md-12">
                           		<?php osc_run_hook('user_register_form'); ?>
                            </div>
                            <div class="clearfix"></div>
                            
                       
                      			<div class="col-md-12">
                        			<?php echo responsive_recaptcha(); ?>
									<?php osc_show_recaptcha('register'); ?>
                                </div>
                            	<div class="clearfix"></div>
                            	<br />
                       
                            
                            <div class="col-md-12">
                            <button type="submit" class="btn btn-success btn-lg col-md-12"><?php _e("Create my free account", 'liberty'); ?> *</button>
                            </div>
                         </form>
                        <div class="clearfix"></div>
                        <br>
                        
                        	<h4 class="text-center terms"><small>* <?php _e("By signing up, you agree to our", 'liberty'); ?>
                            <a href="<?php echo osc_esc_html( osc_get_preference('terms_link', 'liberty_theme') ); ?>"><?php _e("Terms", 'liberty'); ?></a>
                             <?php _e("and", 'liberty'); ?> <a href="<?php echo osc_esc_html( osc_get_preference('privacy_link', 'liberty_theme') ); ?>"><?php _e("Privacy Policy", 'liberty'); ?></a></small></h4>
                        </div>
                        <div class="clearfix"></div>
					</div>
            	</div>
			</div>
    	</div>
</section>



<script type="text/javascript">
document.getElementById("email").setAttribute("placeholder","<?php _e("Email address", 'liberty'); ?>")
document.getElementById("password").setAttribute("placeholder","<?php _e("Password", 'liberty'); ?>")
document.getElementById("s_name").setAttribute("placeholder","<?php _e("Name", 'liberty'); ?>")
document.getElementById("s_email").setAttribute("placeholder","<?php _e("Email address", 'liberty'); ?>")
document.getElementById("s_password").setAttribute("placeholder","<?php _e("Password", 'liberty'); ?>")
document.getElementById("s_password2").setAttribute("placeholder","<?php _e("Repeat password", 'liberty'); ?>")
document.getElementById("s_phone_land").setAttribute("placeholder","<?php _e("Phone", 'liberty'); ?>")
document.getElementById("s_website").setAttribute("placeholder","<?php _e("Website", 'liberty'); ?>")
$(document).ready(function(){
$(".fb-button a").addClass("btn fb-primary btn-lg col-md-12 col-xs-12");
$('.fb-button a').empty().append('<span class="hidden-xs"><?php _e("Login with Facebook", 'liberty'); ?></span> <span class="visible-xs"><?php _e("Login via Fb", 'liberty'); ?></span>');
}); 
</script>
<?php UserForm::js_validation(); ?>    
<?php osc_current_web_theme_path('footer.php') ; ?>