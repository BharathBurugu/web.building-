<?php
// meta tag robots

    osc_add_hook('header','liberty_nofollow_construct');
    liberty_add_body_class('recover');

	osc_enqueue_script('jquery-validate');
    osc_current_web_theme_path('header.php'); ?>
    

    
<section id="login">
    <div class="container">
    	<div class="row">
        	<div class="col-md-0 offset">
        		<div class="box">
                	
				<h3><?php _e('Recover your password', 'liberty'); ?></h3>
           
          
            
                <form action="<?php echo osc_base_url(true); ?>" method="post" >
                    <input type="hidden" name="page" value="login" />
                    <input type="hidden" name="action" value="recover_post" />
        
                        <p class="col-md-12"><?php _e('Email address', 'liberty'); ?> :</p>
                            <div class="col-md-12">
                                <?php UserForm::email_text(); ?>
                              <br />
                              <br />
                        			<?php echo responsive_recaptcha(); ?>
									<?php osc_show_recaptcha('register'); ?>
                                </div>
                                
                                <div class="clearfix"></div>
                                 <br />
                                  
                              
                                 <button type="submit" class="btn btn-success btn-lg col-md-12"><span class="hidden-xs hedden-sm"><?php _e("Send me a new password", 'liberty');?></span><span class="hidden-lg hedden-md"><?php _e("Send", 'liberty');?></button>
                                 <br />
                                 <div class="clearfix"></div>
                            </div>
                         <div class="clearfix"></div>
                       
            
                 </form>
                
     
            	</div>
			</div>
		</div>
</section>


<?php UserForm::js_validation(); ?>    
<?php osc_current_web_theme_path('footer.php') ; ?>