<?php
// meta tag robots
    if( osc_count_items() == 0 || stripos($_SERVER['REQUEST_URI'], 'search') ) {
        osc_add_hook('header','liberty_nofollow_construct');
    } else {
        osc_add_hook('header','liberty_follow_construct');
    }

    liberty_add_body_class('search');
    $listClass = '';
    $buttonClass = '';
    if(osc_search_show_as() == 'gallery'){
          $listClass = 'listing-grid';
          $buttonClass = 'active';
    }

   // osc_add_hook('before-main','sidebar');
    //function sidebar(){
      //  osc_current_web_theme_path('search-sidebar.php');
   // }
    osc_add_hook('footer','autocompleteCity');
?>

<?php osc_current_web_theme_path('header.php') ; ?>

<section id="search">
    <div class="container">
		<div class="row">
        	<div class="hidden"><!---- Hidden Breadcrumb ----->
				<?php osc_breadcrumb(); ?>
			</div>
			<div class="clearfix"></div>
            
        	<div class="col-md-3"><!--------- Sidebar------->
           	<?php echo osc_current_web_theme_path('search-sidebar.php');?>
            </div>
            
            <?php if( osc_get_preference('position3_enable', 'liberty_theme') != '0') { ?>
            <div class="col-md-9 position3 <?php if( osc_get_preference('position3_hide', 'liberty_theme') != '0') {echo"hidden-xs";}?>">
            	<div class="box">
                	<?php echo osc_get_preference('position3_content', 'liberty_theme', "UTF-8"); ?>
                </div>
            </div>
            <?php } ?>
            
        	<div class="col-md-9"><!---------- Search Content ------------->
            	<div class="box">
                    <div class="action-bar">
                    	<div class="heading pull-left">
                         	<h4>
                            <?php if(osc_count_items() == 0) {  _e("No Results", 'liberty'); } else {?>
                            	<?php $search_number = liberty_search_number();
                    			printf(__('%3$d Ads in', 'liberty'), $search_number['from'], $search_number['to'], $search_number['of']); ?> <?php echo search_title(); ?>
                                <?php } ?>
                      		</h4>
                        </div>
                    	<div class="clearfix"></div>
                    </div>
                    <div class="clearfix"></div>
                    
     				<div class="sort-by"><!---------- Sort Order ------------->
     					<div class="pull-left">
							<?php $orders = osc_list_orders();
                            foreach($orders as $label => $params) {
                            $orderType = ($params['iOrderType'] == 'asc') ? '0' : '1'; ?>
                            <?php if(osc_search_order() == $params['sOrder'] && osc_search_order_type() == $orderType) { ?>
                            <ul>
      							<li><?php _e("Sort by:", 'liberty'); ?></li>
     							<li class="<?php echo $label; ?>"><a href="<?php echo osc_esc_html(osc_update_search_url($params)); ?>"><?php echo $label; ?></a></li>
           						<?php } else { ?>
                        		<li class="<?php echo $label; ?>"><a href="<?php echo osc_esc_html(osc_update_search_url($params)); ?>"><?php echo $label; ?></a></li>
                        		<?php } ?>
                    			<?php } ?>
                   				<?php /*?> <?php if( osc_images_enabled_at_items() ) { ?>
        						<li><input type="checkbox" name="bPic" id="withPicture" value="1" <?php echo (osc_search_has_pic() ? 'checked' : ''); ?> /> <?php _e('listings with pictures', 'liberty') ; ?></li>
        						<?php } ?><?php */?>
        						<li class="clearfix"></li>
                         	</ul>
        				</div>
                        
                        
        				<div class="pull-right lview hidden-xs"><!---------- List/Gallery Switch Buttton ------------->
							 <?php
                            function active_list(){
                            $ori=osc_update_search_url();
                            $dub= osc_update_search_url(array('sShowAs'=> 'list'));
                            if( $ori== $dub ) {echo "active";}
                            }
                            function active_grid(){
                            $ori=osc_update_search_url();
                            $dub= osc_update_search_url(array('sShowAs'=> 'gallery'));
                            if( $ori== $dub ) {echo "active";}
                            }
                            ?>
    						<span class="doublebutton <?php echo $buttonClass; ?>">
                   				<a title="List View" href="<?php echo osc_esc_html(osc_update_search_url(array('sShowAs'=> 'list'))); ?>" class="list-button" data-class-toggle="listing-grid" data-destination="#listing-card-list"><i class="fa fa-th-list <?php echo active_list();?>"></i></a>
                   				<a title="Grid View" href="<?php echo osc_esc_html(osc_update_search_url(array('sShowAs'=> 'gallery'))); ?>" class="grid-button" data-class-toggle="listing-grid" data-destination="#listing-card-list"><i class="fa fa-th <?php echo active_grid();?>"></i></a>
              				</span>
        				</div>
                     </div>
                      
                <?php if(osc_count_items() == 0) { ?><!---------- Search Results ------------->
               	<div class="content-wrapper block">
                	<p class="empty" ><?php printf(__('There are no results matching "%s"', 'liberty'), osc_search_pattern()) ; ?></p>
                </div>
                <?php } else { ?>
                <div class="content-wrapper block">
                   <?php osc_run_hook('search_ads_listing_top'); ?>
					<?php
                        $i = 0;
                        osc_get_premiums();
                        if(osc_count_premiums() > 0) {
                       
                        View::newInstance()->_exportVariableToView("listType", 'premiums');
                        View::newInstance()->_exportVariableToView("listClass",$listClass.' premium-list');
                        osc_current_web_theme_path('loop.php');
                        }
                    ?>
                    <div class="clearfix"></div>
                    <?php if(osc_count_items() > 0) {
                        View::newInstance()->_exportVariableToView("listType", 'items');
                        View::newInstance()->_exportVariableToView("listClass",$listClass);
                        osc_current_web_theme_path('loop.php');?>
                    <div class="clearfix"></div>
                    
                    <div class="pull-right"><!---------- Search Paginations ------------->
                        <div class="paginate" ><?php echo osc_search_pagination(); ?></div>
                    </div>
                    <div class="clearfix"></div>
                    <?php } ?>
                </div>
              	<?php } ?>
        	</div>
            
           
        
        
 		
		
        <div class="form-group box visible-xs visible-sm">
        	<h4><?php _e('Refine by category', 'liberty') ; ?></h4>
        	<div class="widget-content">
        	<?php liberty_sidebar_category_search($category['pk_i_id']); ?>
       		</div>
    	</div>
  
            
      <?php if( osc_get_preference('position4_enable', 'liberty_theme') != '0') { ?>
          <div class="box position4 <?php if( osc_get_preference('position4_hide', 'liberty_theme') != '0') {echo"hidden-xs";}?>">
              <?php echo osc_get_preference('position4_content', 'liberty_theme', "UTF-8"); ?>
           </div>
      <?php } ?>
                
</div>
<div class="clearfix"></div>
</div>
</section>

<script>
$(document).ready(function(){
$(".paginate span.searchPaginationSelected").addClass("btn btn-success disabled btn-md");
$(".paginate a").addClass("btn btn-primary btn-md");
$('a.searchPaginationNext').empty().append("<?php _e("Next", 'liberty'); ?> <small>></small>");
$('a.searchPaginationPrev').empty().append("<small><</small> Prev");
});
</script>
<?php osc_current_web_theme_path('footer.php') ; ?>