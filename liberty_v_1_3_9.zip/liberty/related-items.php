<?php if( osc_count_items() > 0 ) { ?>
        
			<div class="row listing-grid">
			<?php
				$i = 2;
		
				if($type == 'latestItems'){
					while ( osc_has_latest_items() ) {
						$class = '';
						if($i%2 == 0){
							$class = 'first';
						}
						liberty_draw_item($class);
						$i++;
					}
				} elseif($type == 'premiums'){
					while ( osc_has_premiums() ) {
						$class = '';
						if($i%2 == 0){
							$class = 'first';
						}
						liberty_draw_item($class,false,true);
						$i++;
						if($i == 2){
							break;
						}
					}
				} else {
					while(osc_has_items()) {
						$i++;
						$class = false;
						if($i%2 == 0){
							$class = 'last';
						}
						$admin = false;
						if(View::newInstance()->_exists("listAdmin")){
							$admin = true;
						}
		
						liberty_draw_item($class,$admin);
				  }
				}
			?>
		</div>              

        <?php } ?>