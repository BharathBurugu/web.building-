<?php

    // meta tag robots
    osc_add_hook('header','liberty_nofollow_construct');

    liberty_add_body_class('forgot');
    osc_current_web_theme_path('header.php');
?>

<section id="login forget">
    <div class="container">
    	<div class="row">
        	<div class="col-md-0 offset">
        		<div class="box">
                <h3><?php _e('Recover your password', 'liberty'); ?></h3>
                
                
        <form action="<?php echo osc_base_url(true); ?>" method="post" >
            <input type="hidden" name="page" value="login" />
            <input type="hidden" name="action" value="forgot_post" />
            <input type="hidden" name="userId" value="<?php echo osc_esc_html(Params::getParam('userId')); ?>" />
            <input type="hidden" name="code" value="<?php echo osc_esc_html(Params::getParam('code')); ?>" />
           <p class="col-md-12"><?php _e('New password', 'liberty'); ?></p>
           <div class="col-md-12">
                    <input type="password" name="new_password" value="" />
                </div>
                
       				<br><br><br><br>
           
                <p class="col-md-12"><?php _e('Repeat new password', 'liberty'); ?></p>
                <div class="col-md-12">
                    <input type="password" name="new_password2" value="" />
              
      
            <br />
                              <br />
                        			<?php echo responsive_recaptcha(); ?>
									<?php osc_show_recaptcha('register'); ?>
                           
                                </div>  
                                <div class="clearfix"></div>
                                 <br />
                                  
                              
                                 <button type="submit" class="btn btn-success btn-lg col-md-12"><span class="hidden-xs hedden-sm"><?php _e("Change password", 'liberty');?></span><span class="hidden-lg hedden-md"><?php _e("Send", 'liberty');?></button>
                                 <br />
                                 <div class="clearfix"></div>
                    
                         <div class="clearfix"></div>
                       
            
                 </form>
                
     
            	</div>
			</div>
</section>


<?php UserForm::js_validation(); ?>    
<?php osc_current_web_theme_path('footer.php') ; ?>