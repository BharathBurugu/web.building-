<style>
#top, .custom-select:after, .btn-primary, .ui-slider-range, #footer-bottom, .lib-primary {
background:#<?php echo osc_esc_html( osc_get_preference('color_sch', 'liberty_theme') ); ?> !important;
}
.m-cat li i, #log li a, #head-bottom .dropdown .fa, a.title {
color:#<?php echo osc_esc_html( osc_get_preference('color_sch', 'liberty_theme') ); ?> !important;
}
</style>