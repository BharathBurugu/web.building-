<script type="text/javascript">
$(document).ready(function(){
    $(".subtn").click(function(){
        $.post('<?php echo osc_base_url(true); ?>', {email:$("#alert_email").val(), userid:$("#alert_userId").val(), alert:$("#alert").val(), page:"ajax", action:"alerts"},
            function(data){
                if(data==1) { alert('<?php echo osc_esc_js(__('You have sucessfully subscribed to the alert', 'liberty')); ?>');
				 if(confirm){
        			window.location.reload();
				}
				 }
                else if(data==-1) { alert('<?php echo osc_esc_js(__('Invalid email address', 'liberty')); ?>');
				
				 }
                else { alert('<?php echo osc_esc_js(__('There was a problem with the alert', 'liberty')); ?>');
				 };
				 
        });
        return false;
    });

    var sQuery = '<?php echo osc_esc_js(AlertForm::default_email_text()); ?>';

    if($('input[name=alert_email]').val() == sQuery) {
        //$('input[name=alert_email]').css('color', 'gray');
    }
    $('input[name=alert_email]').click(function(){
        if($('input[name=alert_email]').val() == sQuery) {
            $('input[name=alert_email]').val('');
            //$('input[name=alert_email]').css('color', '');
        }
    });
    $('input[name=alert_email]').blur(function(){
        if($('input[name=alert_email]').val() == '') {
            $('input[name=alert_email]').val(sQuery);
            //$('input[name=alert_email]').css('color', 'gray');
        }
    });
    $('input[name=alert_email]').keypress(function(){
        //$('input[name=alert_email]').css('background','');
    })
});
</script>

<h4><?php _e('Enter your email address', 'liberty'); ?></h4>
<div class="widget-content">
    <form action="<?php echo osc_base_url(true); ?>" role="form" method="post" name="sub_alert" id="sub_alert" class="nocsrf">
            <?php AlertForm::page_hidden(); ?>
            <?php AlertForm::alert_hidden(); ?>

            <?php if(osc_is_web_user_logged_in()) { ?>
            	<div class="form-group">
                <?php AlertForm::user_id_hidden(); ?>
                <?php AlertForm::email_hidden(); ?>
                </div>
				<div align="center"><h5 style=" margin-bottom:10px;"><?php echo osc_logged_user_name(); ?>, you are signed in.</h5><button type="submit" class="btn btn-default subtn"><?php _e('Subscribe now', 'liberty'); ?>!</button></div>
            <?php } else { ?>
            	<div class="form-group">
                <?php AlertForm::user_id_hidden(); ?>
                <?php AlertForm::email_text(); ?>
                </div>
				<?php /*?><button aria-hidden="true" data-dismiss="modal" type="submit" class="close btn btn-primary btn-md col-md-12 subtn"><?php _e('Subscribe now', 'liberty'); ?></button><?php */?>
            <?php }; ?>           
    </form>
</div>