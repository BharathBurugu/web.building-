<?php
	// meta tag robots
    osc_add_hook('header','liberty_nofollow_construct');

    osc_enqueue_script('jquery-validate');
    liberty_add_body_class('user user-profile');
    //osc_add_hook('before-main','sidebar');
    //function sidebar(){
    //    osc_current_web_theme_path('user-sidebar.php');
   // }
    osc_add_filter('meta_title_filter','custom_meta_title');
    function custom_meta_title($data){
        return __('Change e-mail', 'liberty');;
    }
    osc_current_web_theme_path('header.php') ;
    $osc_user = osc_user();
?>

<section id="myaccount">
    <div class="container">
		<div class="row">
        	<div class="col-md-3 hidden-xs hidden-sm">
            	<?php echo osc_current_web_theme_path('user-sidebar.php');?>
            </div>
           	<div class="col-md-9">
           		<div class="box">
                <?php UserForm::location_javascript(); ?>
                    	<h3><?php _e('Change e-mail', 'liberty'); ?></h3>
    	<div class="inner-wrapper">
        <ul id="error_list"></ul>
       <form action="<?php echo osc_base_url(true); ?>" class="form-horizontal" role="form"  method="post">
            <input type="hidden" name="page" value="user" />
            <input type="hidden" name="action" value="change_email_post" />
            <div class="form-group">
                <label for="email" class="col-sm-2 control-label"><?php _e('Current e-mail', 'liberty'); ?></label>
                <div class="col-sm-5">
                  <p class="form-control-static"><?php echo osc_logged_user_email(); ?></p>
                </div>
            </div>
            <div class="form-group">
                <label for="new_email" class="col-sm-2 control-label"><?php _e('New e-mail', 'liberty'); ?></label>
                <div class="col-sm-5">
                  <input type="text" name="new_email" id="new_email" value="" />
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-5">
                  <button type="submit" class="btn btn-primary"><?php _e("Update", 'liberty'); ?></button>
                </div>
            </div>
        </form>
                </div>
            </div>
        </div>
        <div class="col-md-3 visible-xs visible-sm">
            	<?php echo osc_current_web_theme_path('user-sidebar.php');?>
            </div>
     	</div>
    </div>
</section>
<script type="text/javascript">
    $(document).ready(function() {
        $('form#change-email').validate({
            rules: {
                new_email: {
                    required: true,
                    email: true
                }
            },
            messages: {
                new_email: {
                    required: '?php echo osc_esc_js(__("Email: this field is required", "boxer")); ?>.',
                    email: '<?php echo osc_esc_js(__("Invalid email address", "liberty")); ?>.'
                }
            },
            errorLabelContainer: "#error_list",
            wrapper: "li",
            invalidHandler: function(form, validator) {
                $('html,body').animate({ scrollTop: $('h1').offset().top }, { duration: 250, easing: 'swing'});
            },
            submitHandler: function(form){
                $('button[type=submit], input[type=submit]').attr('disabled', 'disabled');
                form.submit();
            }
        });
    });
</script>
<?php osc_current_web_theme_path('footer.php') ; ?>