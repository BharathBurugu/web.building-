$(function() {
   

   
   
    
    //price range
    $("#price-range").slider({
        range: true,
        min: 0,
        max: 10000,
        step: 500,
        values: [0, 10000],
        slide: function(event, ui) {
            $('#priceMin').val(ui.values[0]);
            $('#priceMax').val(ui.values[1]);
        },
        create:function(){
            var values = $(this).slider( "option", "values" );
            $('#priceMin').val(values[0]);
            $('#priceMax').val(values[1]);
        }
    });

    //HACK FOR REALSTATE PLUGIN
    $("#sidebar .form-hook .slider").each(function(){
        var thatElement = $(this);
        var thatSlider = thatElement.children('div');
        var minValue = $('<input type="text" class="min" readonly/>');
        var maxValue = $('<input type="text" class="max" readonly/>');
        thatElement.removeClass('slider').addClass('ui-slider-box').append(minValue,maxValue);
        thatSlider.bind( "slide", function(event, ui) {
            minValue.val(ui.values[0]);
            maxValue.val(ui.values[1]);
        }).bind( "slidecreate", function() {
            var values = $(this).slider( "option", "values" );
            minValue.val(values[0]);
            maxValue.val(values[1]);
        });

    });
    //remove empty p
    $("#sidebar .form-hook p").filter( function() {
        return $.trim($(this).html()) == '';
    }).remove()

    $('.js-submit').click(function(){
        $(this).parents('form').submit();
        return false;
    });

    $('html').click(function(e) {
        e.stopPropagation();
        $('.ui-selectmenu-show').removeClass('ui-selectmenu-show');
    });
});

