<?php

    // meta tag robots
    osc_add_hook('header','liberty_nofollow_construct');

    liberty_add_body_class('user user-items');
    //osc_add_hook('before-main','sidebar');
   // function sidebar(){
    //    osc_current_web_theme_path('user-sidebar.php');
  //  }
    osc_current_web_theme_path('header.php') ;

    $listClass = '';
    $buttonClass = '';
    if(Params::getParam('ShowAs') == 'gallery'){
        $listClass = 'listing-grid';
        $buttonClass = 'active';
    }
?>
<section id="myaccount">
    <div class="container">
		<div class="row">
       		<div class="col-md-3 hidden-xs hidden-sm">
            	<?php echo osc_current_web_theme_path('user-sidebar.php');?>
            	</div>
           	<div class="col-md-9">
           		<div class="box">
                	<h3><?php _e('My listings', 'liberty'); ?></h3>
       				<?php if(osc_count_items() == 0) { ?>
            		<p class="empty"><?php _e('No listings have been added yet', 'liberty'); ?></p>
        			<?php } else { ?>
                	<?php
                        View::newInstance()->_exportVariableToView("listClass",$listClass);
                        View::newInstance()->_exportVariableToView("listAdmin", true);
                        osc_current_web_theme_path('user-lists.php');
                    ?>
                    <div class="paginate" >
            		<?php echo osc_pagination_items(); ?>
                    </div>
        			<?php } ?>
                </div>
                <div class="clearfix"></div>
            </div>
            	<div class="col-md-3 visible-xs visible-sm">
            	<?php echo osc_current_web_theme_path('user-sidebar.php');?>
            	</div>
       		
        </div>
    </div>
</section>
<script>
$(document).ready(function(){

    $(".paginate span.searchPaginationSelected").addClass("btn btn-success disabled btn-md");
	 $(".paginate a").addClass("btn btn-primary btn-md");

	$('a.searchPaginationNext').empty().append("Next <small>></small>");
	$('a.searchPaginationPrev').empty().append("<small><</small> Prev");
   


});

</script>
<?php osc_current_web_theme_path('footer.php') ; ?>