<?php
    osc_add_hook('header','liberty_nofollow_construct');

    osc_enqueue_script('jquery-validate');
    liberty_add_body_class('item item-post');
    $action = 'item_add_post';
    $edit = false;
    if(Params::getParam('action') == 'item_edit'){
        $action = 'item_edit_post';
        $edit = true;
    }

    ?>

<?php osc_current_web_theme_path('header.php') ; ?>
<?php ItemForm::location_javascript(); ?>
<section id="item-post">
    <div class="container">
		<div class="row">
       		<div class="offset">
            	<?php if( osc_get_preference('position7_enable', 'liberty_theme') != '0') { ?>
          			<div class="box position7 <?php if( osc_get_preference('position7_hide', 'liberty_theme') != '0') {echo"hidden-xs";}?>">
              			<?php echo osc_get_preference('position7_content', 'liberty_theme', "UTF-8"); ?>
           			</div>
      			<?php } ?>
            
            
       			<form name="item" action="<?php echo osc_base_url(true);?>" method="post" enctype="multipart/form-data" id="item-post">
                 	<input type="hidden" name="action" value="<?php echo $action; ?>" />
                    <input type="hidden" name="page" value="item" />
                    <?php if($edit){ ?>
                        <input type="hidden" name="id" value="<?php echo osc_item_id();?>" />
                        <input type="hidden" name="secret" value="<?php echo osc_item_secret();?>" />
                    <?php } ?>
                    
                    <div class="box"><!--------- Genral Informations ----->
                        <h3><?php _e('General Informations', 'liberty'); ?></h3>
                        <div class="clearfix"></div>
                            <br>
                            <div class="col-md-6">
                            <label class="control-label" for="select_1"><?php _e('Category', 'liberty'); ?></label>
                            <div class="controls">
                                <?php ItemForm::category_select(null, null, __('Select a category', 'liberty')); ?>
                            </div>
                        </div>
                        <div class="visible-xs visible-sm">
                        <div class="clearfix"></div>
                        <br>
                        </div>
                        <?php if( osc_price_enabled_at_items() ) { ?>
                      		<div class="col-md-4">
                            <label class="control-label" for="price"><?php _e('Price', 'liberty'); ?></label>
                            <div class="controls">
                                <?php ItemForm::price_input_text(); ?>
                            </div>
                        	</div>
                        
                        	<div class="col-md-2">
                            	<label class="control-label" for="price">&#160;&#160;</label>
                            	<div class="controls">
									<?php ItemForm::currency_select(); ?>
                                </div>
                        	</div>
                        <?php } ?>
                        <div class="clearfix"></div>
                        <br>
                        <div class="col-md-12">
                            <label class="control-label" for="title[<?php echo osc_locale_code(); ?>]"><?php _e('Title', 'liberty'); ?></label>
                            <div class="controls">
                                <?php ItemForm::title_input('title',osc_locale_code(), osc_esc_html( liberty_item_title() )); ?>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <br>
                        <div class="col-md-12">
                            <label class="control-label" for="description[<?php echo osc_locale_code(); ?>]"><?php _e('Description', 'liberty'); ?></label>
                            <div class="controls">
                                <?php ItemForm::description_textarea('description',osc_locale_code(), osc_esc_html( liberty_item_description() )); ?>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <?php
                        if($edit) {
                            ItemForm::plugin_edit_item();
                        } else {
                            ItemForm::plugin_post_item();
                        }
                        ?>
             		</div><!--box-->
                    
					<?php if( osc_images_enabled_at_items() ) {?><!------------ Image Upload --------------------------->
					<div class="col-md-12 box">
                        <h3><?php _e('Upload Images', 'liberty'); ?></h3>
                         <?php ItemForm::ajax_photos();?>
                         <div class="clearfix"></div>
						 </div>
					<?php  } ?>
                    <div class="clearfix"></div>
                    <script type="text/javascript">
$(document).ready(function(){
$('.qq-upload-button div').append('<br> <br> <i class="fa fa-plus-circle"></i>');
$('.qq-upload-list li:last-child').append('<div class="clearfix"></div>');
});
</script>
                 
                	<div class="box location"><!------------ Listing Locations --------------->
                    	<h3><?php _e('Listing Location', 'liberty'); ?></h3>
						<div class="clearfix"></div>
                        <br>
                        <?php  if (count(osc_get_countries()) == 0 || count(osc_get_countries()) > 1) { ?>
                        <div class="col-md-6">
                        	<label class="control-label" for="country"><?php _e('Country', 'liberty'); ?></label>
                        	<div class="controls">
                        	<?php ItemForm::country_select(osc_get_countries(), osc_user()); ?>
                        	</div>
                    	</div>
                        <?php } else { ?>
                        <div class="col-md-6">
                        	<label class="control-label" for="country"><?php _e('Country', 'liberty'); ?></label>
                        	<div class="controls">
                        	<?php //ItemForm::country_select(osc_get_countries(), osc_user()); ?>
                            <?php ItemForm::country_text(); ?>
                        	</div>
                    	</div>
                        <?php } ?>
                    
                    <div class="visible-xs visible-sm">
                    	<div class="clearfix"></div>
                    	<br>
                    </div>
                   	<div class="col-md-6">
                    	<label class="control-label" for="region"><?php _e('Region', 'liberty'); ?></label>
                        	<div class="controls">
                            <?php ItemForm::region_select(osc_get_regions(), osc_user()); ?>
                           		<?php //ItemForm::region_text(osc_user()); ?>
                            </div>
                     </div>
                     <div class="clearfix"></div>
                     <br>
                     <div class="col-md-6">
                     	<label class="control-label" for="city"><?php _e('City', 'liberty'); ?></label>
                        <div class="controls">
                        	<?php //ItemForm::city_select(osc_user()); ?>
                             <?php ItemForm::city_select(osc_get_cities(), osc_user()); ?>
                         </div>
                    </div>
                    <div class="visible-xs visible-sm">
                     	<div class="clearfix"></div>
                     	<br>
                    </div>
					<div class="col-md-6">
                    	<label class="control-label" for="cityArea"><?php _e('City Area', 'liberty'); ?></label>
                        <div class="controls">
                        	<?php ItemForm::city_area_text(osc_user()); ?>
                        </div>
                    </div>
                   	<div class="clearfix"></div>
                    <br>
					<div class="col-md-12">
                    	<label class="control-label" for="address"><?php _e('Address', 'liberty'); ?></label>
                        <div class="controls">
                        	<?php ItemForm::address_text(osc_user()); ?>
                        </div>
                    </div>
                    <div class="clearfix"></div>
               </div><!--box-->
                        
            
              <!----------------- seller information -------------->
              <div class="box seller_info">
              
               <?php if(!osc_is_web_user_logged_in() ) { ?>
               	<h3><?php _e("Seller's information", 'liberty'); ?></h3>
                <div class="clearfix"></div>
				<br>
				<div class="col-md-12">
                	<label class="control-label" for="contactName"><?php _e('Name', 'liberty'); ?></label>
                   	<div class="controls">
                    	<?php ItemForm::contact_name_text(); ?>
                    </div>
                 </div>
                 <div class="clearfix"></div>
				<br>
				<div class="col-md-12">
             		<label class="control-label" for="contactEmail"><?php _e('E-mail', 'liberty'); ?></label>
                    	<div class="controls">
                          	<?php ItemForm::contact_email_text(); ?>
                           	<?php ItemForm::show_email_checkbox(); ?> <label for="showEmail"><?php _e('Show e-mail on the listing page', 'liberty'); ?></label>
                       	</div>
                     </div>
                <div class="clearfix"></div>
                <?php } ?>
				<br>
                <?php if( osc_recaptcha_items_enabled() ) { ?>
                      <div class="col-md-12">
                      
                        <?php echo responsive_recaptcha(); ?>
                        <?php osc_show_recaptcha('register'); ?>
                         </div>
                            <div class="clearfix"></div>
                            <br />
                        <?php } ?>
                        
				
				<div class="col-md-12"><!----------------- Post Button -------------->
                	<div class="controls">
                     	<button type="submit" class="btn btn-primary btn-md pull-right"><?php if($edit) { _e("Update", 'liberty'); } else { _e("Publish", 'liberty'); } ?></button>
                     </div>
                </div>
                <div class="clearfix"></div>
                </div><!--box--><!-- seller info -->
                <div class="clearfix"></div>
             	</form>
             </div>
         </div>
     </div>
</section>
	
<script type="text/javascript">
    <?php if(osc_locale_thousands_sep()!='' || osc_locale_dec_point() != '') { ?>
    $().ready(function(){
        $("#price").blur(function(event) {
            var price = $("#price").prop("value");
            <?php if(osc_locale_thousands_sep()!='') { ?>
            while(price.indexOf('<?php echo osc_esc_js(osc_locale_thousands_sep());  ?>')!=-1) {
                price = price.replace('<?php echo osc_esc_js(osc_locale_thousands_sep());  ?>', '');
            }
            <?php }; ?>
            <?php if(osc_locale_dec_point()!='') { ?>
            var tmp = price.split('<?php echo osc_esc_js(osc_locale_dec_point())?>');
            if(tmp.length>2) {
                price = tmp[0]+'<?php echo osc_esc_js(osc_locale_dec_point())?>'+tmp[1];
            }
            <?php }; ?>
            $("#price").prop("value", price);
        });
    });
    <?php }; ?>
</script>


<?php osc_current_web_theme_path('footer.php'); ?>