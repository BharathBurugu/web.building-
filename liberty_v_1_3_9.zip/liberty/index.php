<?php
/*
Theme Name: Liberty
Theme URI: http://www.drizzlethemes.com/
Description: Liberty Responsive Osclass Theme
Version: 1.3.9
Author: DrizzleThemes
Author URI: http://www.drizzlethemes.com/
Widgets: Sidebar
Theme update URI: liberty-responsive-theme
*/

    function liberty_theme_info() {
        return array(
             'name'        => 'liberty'
            ,'version'     => '1.3.9'
            ,'description' => 'Liberty Responsive Osclass Theme'
            ,'author_name' => 'DrizzleThemes'
            ,'author_url'  => 'http://www.drizzlethemes.com'
            ,'locations'   => array()
        );
    }

?>