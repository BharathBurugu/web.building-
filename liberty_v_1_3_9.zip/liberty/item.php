<?php
    // meta tag robots
    osc_add_hook('header','liberty_follow_construct');

    liberty_add_body_class('item');

    $location = array();
    if( osc_item_city_area() !== '' ) {
        $location[] = osc_item_city_area();
    }
    if( osc_item_city() !== '' ) {
        $location[] = osc_item_city();
    }
    if( osc_item_region() !== '' ) {
        $location[] = osc_item_region();
    }
    if( osc_item_country() !== '' ) {
        $location[] = osc_item_country();
    }
	 osc_enqueue_script('fancybox');
    osc_enqueue_style('fancybox', osc_current_web_theme_url('js/fancybox/jquery.fancybox.css'));
    osc_enqueue_script('jquery-validate');
    osc_current_web_theme_path('header.php');
?>
<section id="item">
    <div class="container">
		<div class="row">
        	<div class="col-md-12">
            	<div class="box"><!---------- Breadcrumb -------------->
					<?php $breadcrumb = osc_breadcrumb('', false, get_breadcrumb_lang()); if( $breadcrumb !== '') { ?>
                    	<?php echo $breadcrumb; ?>
                    <?php } ?>
                    
                    <h3 class="visible-xs"><?php echo osc_item_title(); //osc_highlight( strip_tags(  ), 40 ) ; ?></h3><!--- Item Title For Moblie---->
                    <div id="item-content">
                    <div class="item-photos col-md-5 col-sm-5 col-xs-12"><!---- Item Photo ---->
                   <?php if( osc_images_enabled_at_items() ) { ?>
                    <?php if( osc_count_item_resources() >= 2 ) { ?> 
                    <div id="carousel-bounding-box"> 
                        <div class="carousel slide" id="item-resource" data-interval="false">
                        <div class="carousel-inner text-center">
                        <div class="active item" data-slide-number="0">
                        <a href="<?php echo osc_resource_url(); ?>" data-fancybox-group="gallery" class="fancybox" title="<?php _e('Image', 'boxer'); ?> <?php echo $i+1;?> / <?php echo osc_count_item_resources();?>"><img class="img-responsive" src="<?php echo osc_resource_url(); ?>" alt="<?php echo osc_item_title(); ?>" /></a>
                        </div>
						<?php for ( $i > 1; osc_has_item_resources(); $i++ ) { ?>
                            <?php if( $i >= 1 ) { ?>
                                <div class="item" data-slide-number="<?php print $i; ?>">
                                    <a href="<?php echo osc_resource_url(); ?>" data-fancybox-group="gallery" class="fancybox" title="<?php _e('Image', 'boxer'); ?> <?php echo $i+1;?> / <?php echo osc_count_item_resources();?>"><img src="<?php echo osc_resource_url(); ?>" class="img-responsive" alt="<?php echo osc_item_title(); ?>" /></a>
                                </div>
                            <?php } ?>
                        <?php } ?>
                        </div>
                        <a class="carousel-control left" data-slide="prev" href="#item-resource"><i class="fa fa-chevron-left fa-lg"></i></a> <a class="carousel-control right" data-slide="next" href="#item-resource"><i class="fa fa-chevron-right fa-lg"></i></a>
                        </div>
                    </div>
                    <div class="slider-thumbs clearfix"><!--- Item Photo Thumbs ---->
                        <ul>
                        <?php osc_reset_resources(); ?>
                            <?php for ( $i = 0; osc_has_item_resources(); $i++ ) { ?>
                                <?php if( $i >= 0 ) { ?>
                                <li><a name="<?php echo osc_resource_name() ; ?>" id="carousel-selector-<?php print $i; ?>"><img src="<?php echo osc_resource_thumbnail_url(); ?>" alt="<?php echo osc_item_title(); ?>" /></a></li>
                                <?php } ?>
                            <?php } ?>
                        </ul>
                    </div>
					<script>
                    jQuery(document).ready(function($) {
						$('#item-resource').carousel({
								interval: false
						});
						
						//Handles the carousel thumbnails
						$('[id^=carousel-selector-]').click( function(){
								var id_selector = $(this).attr("id");
								var id = id_selector.substr(id_selector.lastIndexOf("-")+1);
								var id = parseInt(id);
								$('#item-resource').carousel(id);
						});
                    });
                    </script>
                    <?php } else if( osc_count_item_resources() == 1 ) { ?><!--- If No Thumbs Show Single --->
                    	<div class="singleimage text-center">
                    		<a href="<?php echo osc_resource_url(); ?>" data-fancybox-group="gallery" class="fancybox" title="<?php _e('Image', 'boxer'); ?> <?php echo $i+1;?> / <?php echo osc_count_item_resources();?>"><img class="img-responsive" src="<?php echo osc_resource_url(); ?>" alt="<?php osc_item_title(); ?>" /></a>
                    	</div>
                    <?php } else { ?><!--- If No Image Show Google ad --->
                      <?php if( osc_get_preference('google_ad', 'liberty_theme') !== '0') { ?>
                    <div class="col-md-5 col-sm-5 hidden-xs g-ads">
                    	<?php echo show_adsense(); ?>
                    </div>
                    <?php } ?>
                    <?php } ?>
                    <script>
						$(document).ready(function() {
						$('.fancybox').fancybox();
						});
						
					</script>
                    <?php } ?>
                    </div>
                    <!-- Photos End -->
                    
                  <div id="description" class="<?php if( osc_get_preference('google_ad', 'liberty_theme') !== '0' || osc_count_item_resources() >= 1 ) { ?>col-sm-7<?php } else {?>col-sm-12<?php } ?> col-xs-12">					 					<!---- Item Details ---->
                    
                    	<h3 class="hidden-xs"><?php echo osc_item_title(); //osc_highlight( strip_tags(  ), 40 ) ; ?></h3>
                       <?php /*?> <p><?php echo osc_item_description(); ?><?php // osc_highlight( strip_tags( osc_item_description() ), 300 ) ;  ?></p><?php */?>
                        
                        <div id="item-fields"><!------ Price and Share Icons ------>
                        	<p style="border-bottom:1px dotted #E1E1E1;"><?php if( osc_price_enabled_at_items() ) { ?><span class="price"><?php echo osc_item_formated_price(); ?></span> <?php } ?>
                                 <span class="hidden-xs pull-right" style="border:none;">
                                   	<span class='st_facebook_large' displayText='Facebook'></span>
                                   	<span class='st_twitter_large' displayText='Tweet'></span>
                                   	<span class='st_linkedin_large' displayText='LinkedIn'></span>
                                   	<span class='st_googleplus_large' displayText='Google +'></span>
                                   	<span class='st_pinterest_large' displayText='Pinterest'></span>
                                   	<span class='st_sharethis_large' displayText='ShareThis'></span>
                                  	<span class='st_email_large' displayText='Email'></span>
                                  </span>
                              </p>
                              <br />
                              
                              <!----- Item Meta --->
                              <p><span><i class="fa fa-map-marker"></i><?php // _e("Location:", 'liberty'); ?></span> <?php echo implode(', ', $location); ?></p>
                              <p><span><i class="fa fa-folder-open"></i><?php //_e("Category:", 'liberty'); ?></span> <?php echo osc_item_category(); ?></p>
                              <p><span><i class="fa fa-calendar-o"></i> <?php //_e("Posted on:", 'liberty'); ?></span> <?php if ( osc_item_pub_date() !== '' ) { printf( __('%1$s', 'liberty'), osc_format_date( osc_item_pub_date() ) ); } ?> <?php _e('at', 'liberty'); ?> <?php echo cust_format_date_with_time(osc_item_pub_date()); ?></p>
                              <br/>
                              
                           <!----- Map Button --->    
                           
                           <?php /*?> <button  data-toggle="modal" data-target="#showmap" class="mapbtn btn btn-primary btn-md"> <?php _e("Show map", 'liberty'); ?></button><?php */?>
                           
                            <!----- Waatch List --->  
                            <?php if (function_exists("watchlist")) { ?>
                            	<?php if( osc_is_web_user_logged_in() ) { ?>
                            		<button data-toggle="modal" data-target="#watchlist" class="wlist btn btn-primary btn-md"><?php _e("Add to watchlist", 'liberty'); ?></button>
                            	<?php } else { ?>
                                    <button data-toggle="modal" data-target="#wlogin" class="wlogin btn btn-primary btn-md"><?php _e("Login to add watchlist", 'liberty'); ?></button>
                                <?php } ?>
                            <?php } ?>
                              
                            <!----- Report / Edit Button --->           
                           	<?php if(osc_is_web_user_logged_in() && osc_logged_user_id()==osc_item_user_id()) { ?>
                            	<a class="btn btn-primary btn-md" href="<?php echo osc_item_edit_url(); ?>"rel="nofollow"><?php _e("Edit this ad", 'liberty'); ?></a>
                       		<?php } else { ?>
                    			<button data-toggle="modal" data-target="#spam" class="btn btn-primary btn-md"><?php _e("Report this ad", 'liberty'); ?></button>
							<?php } ?>
                          </div>
                       </div>  
                   	</div>
            		<div class="clearfix"></div>  
                  </div><!-- Item Content -->
                 <div class="clearfix"></div>  
               </div><!--box-->
             <div class="clearfix"></div>  
           </div>
        </div>
    </div>
</section>

<!------------- Comment ------------->
<section id="item">
    <div class="container">
		<div class="row">
        	<div class="col-md-8">
            <div class="box item-description">
            <h3><?php _e('Description', 'liberty'); ?></h3>
             <p><?php echo osc_item_description(); ?></p>
            </div>
            
            <?php /*?><div class="msidebar visible-xs visible-sm">
            <?php echo osc_current_web_theme_path('item-sidebar.php');?>
            </div><?php */?>
            <div class="box glocation"><!---- Google Map ---->
            	<h3><?php _e('Location', 'liberty'); ?></h3>
                <div class="ifempty"><?php osc_run_hook('location'); ?></div>
            </div>
            
         <?php if( osc_get_preference('position5_enable', 'liberty_theme') != '0') { ?>
          <div class="box position5 <?php if( osc_get_preference('position5_hide', 'liberty_theme') != '0') {echo"hidden-xs";}?>">
              <?php echo osc_get_preference('position5_content', 'liberty_theme', "UTF-8"); ?>
           </div>
      	<?php } ?>
            
            <?php if( osc_comments_enabled() ) { ?>
            	<div class="box hidden-xs">  <!--comments--->
                <h3><?php if ( osc_count_item_comments () <= 1 ) { ?>
                 <?php _e('Comment', 'liberty'); ?>
            <?php } else { ?>
                <?php echo osc_count_item_comments(); ?> <?php _e('Comments', 'liberty'); ?>
            <?php } ?></h3>
                	<div id="comments">
                    <ul id="comment_error_list"></ul>
                    <?php CommentForm::js_validation(); ?>
                    <?php if( osc_count_item_comments() >= 1 ) { ?>
                    
                    <div class="comments_list">
                        <?php while ( osc_has_item_comments() ) { ?>
                            <div class="comment clearfix">
                            <div class="pull-left avatar profile">
                            <?php if (function_exists("profile_picture_show")) { ?>
								<?php comment_picture_show(); ?>
                            <?php } else { ?>

                			<img src="http://www.gravatar.com/avatar/<?php echo md5( strtolower( trim( osc_logged_user_email() ) ) ); ?>?s=60"/>
                			<?php } ?>
                            </div>
                            <div class="title">
                            <strong><a href="<?php echo osc_user_public_profile_url(osc_comment_user_id()); ?>" ><?php echo osc_comment_author_name(); ?></a></strong>
                            <span class="pull-right"><?php echo osc_comment_pub_date(); ?></span>
                            </div>
                           <p style="font-size:13px;"><?php echo nl2br( osc_comment_body() ); ?></p>
                            <?php if ( osc_comment_user_id() && (osc_comment_user_id() == osc_logged_user_id()) ) { ?>
                           <p><a rel="nofollow" href="<?php echo osc_delete_comment_url(); ?>" title="<?php _e('Delete your comment', 'liberty'); ?>"><?php _e('Delete', 'liberty'); ?></a>
                            </p>
                            <?php } ?>
                            </div>
                          
                        <?php } ?>
                            <div class="paginate">
                                <?php echo osc_comments_pagination(); ?>
                            </div>
                        </div>
                        <?php } else { ?>
                        <div class="no-comments">
                            <p><?php _e('No Comments', 'liberty'); ?></p>
                        </div>
                        <?php } ?>
						
						<?php if( osc_reg_user_post_comments () && osc_is_web_user_logged_in() || !osc_reg_user_post_comments() ) { ?>
                        <div class="non-content-wrapper">
                            <h4><?php _e('Leave your comment', 'liberty'); ?> <small>(<?php _e('spam and offensive messages will be removed', 'liberty'); ?>)</small></h4>
                            <form action="<?php echo osc_base_url(true); ?>" class="form-horizontal" role="form" method="post" name="comment_form" id="comment_form">
                            <input type="hidden" name="action" value="add_comment" />
                            <input type="hidden" name="page" value="item" />
                            <input type="hidden" name="id" value="<?php echo osc_item_id(); ?>" />
                            <?php if(osc_is_web_user_logged_in()) { ?>
                            <input type="hidden" name="authorName" value="<?php echo osc_esc_html( osc_logged_user_name() ); ?>" />
                            <input type="hidden" name="authorEmail" value="<?php echo osc_logged_user_email();?>" />
                            <?php } else { ?>
                            <div class="form-group">
                                <label class="col-sm-3 control-label" for="authorName"><?php _e('Your name', 'liberty'); ?></label>
                                <div class="col-sm-8">
                                    <?php CommentForm::author_input_text(); ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label" for="authorEmail"><?php _e('Your e-mail', 'liberty'); ?></label>
                                <div class="col-sm-8">
                                    <?php CommentForm::email_input_text(); ?>
                                </div>
                            </div>
                            <?php }; ?>
                            <div class="form-group">
                                <label class="col-sm-3 control-label" for="body"><?php _e('Comment', 'liberty'); ?></label>
                                <div class="col-sm-8">
                                    <?php CommentForm::body_input_textarea(); ?>
                                </div>
                            </div>
                            
                         
                            
                            <div class="form-group">
                                <div class="col-sm-offset-4 col-sm-7">
                                  <button type="submit" class="btn btn-primary pull-right"><?php _e('Post Comment', 'liberty'); ?></button>
                                </div>
                              </div>
                              </form>
                        </div>
                             <?php } else { ?>
                                <p><?php _e("You must be logged in to comment.", 'liberty'); ?> <a href="<?php echo osc_user_login_url(); ?>"><?php _e("Login", 'Liberty'); ?></a> <?php _e("or", 'liberty'); ?> <a href="<?php echo osc_register_account_url(); ?>"><?php _e("Register", 'liberty'); ?></a></p>
                                <?php } ?>  
                    </div>
                    
                    
                    </div>
                 <?php } ?>

                    
                    
                     <div class="box hidden-xs">
						<?php related_listings(); ?>
                        <h3><?php _e('Related listings', 'liberty'); ?></h3>
        				<div class="related-items block">
            			<?php  osc_current_web_theme_path('related-items.php'); ?>
                        </div>
        			</div>
                    
       <?php if( osc_get_preference('position6_enable', 'liberty_theme') != '0') { ?>
          <div class="box position6 <?php if( osc_get_preference('position6_hide', 'liberty_theme') != '0') {echo"hidden-xs";}?>">
              <?php echo osc_get_preference('position6_content', 'liberty_theme', "UTF-8"); ?>
           </div>
      	<?php } ?>
        
              	</div>
             <div class="col-md-4">
            
                		
    		<?php echo osc_current_web_theme_path('item-sidebar.php');?>
 
           
             </div>
             <div class="clearfix"></div>
         </div>
     </div>
</section>

<!---- Model For Login to watchlist ------------------------> 
<div class="modal fade" id="wlogin" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
        <div class="modal-content">
			<div class="modal-header">
				<h3 id="myModalLabel" class="modal-title"><?php _e("Login to add watchlist", 'liberty'); ?></h3>
			</div>
			<div class="modal-body">
			<div class="elogin">
				<div class="col-md-12">
					<form action="<?php echo osc_base_url(true); ?>" class="form-horizontal" role="form" method="post" >
            		<input type="hidden" name="page" value="login" />
                    <input type="hidden" name="action" value="login_post" />
 					<?php UserForm::email_login_text(); ?>
				</div>
				<div class="clearfix"></div>
				<br>
				<div class="col-md-12">
					<?php UserForm::password_login_text(); ?>
				</div>
				<div class="clearfix"></div>
				<br />
				<div class="col-md-6 col-xs-8">
					<div class="checkbox">
						<?php UserForm::rememberme_login_checkbox();?> 
						<h3><small><?php _e('Stay signed in', 'liberty'); ?></small></h3>
                 	</div>
                </div>
  				<div class="col-md-6 col-xs-4 text-right">              
					<h3><a href="<?php echo osc_recover_user_password_url(); ?>"><small><?php _e("Forgot password?", 'liberty'); ?></a></h3>
				</div>
				<div class="clearfix"></div>
				<br>
				<div class="col-md-12">
					<button type="submit" class="btn btn-success btn-lg col-md-12 col-xs-12"><?php _e("Sign in", 'liberty'); ?></button>
				</div>
				<div class="clearfix"></div>
				<?php if (function_exists("fbc_button")) { ?>
               		<div class="col-md-12 fb-button">
                    	<?php fbc_button(); ?>
                    </div>
               	<?php } ?>
				</form>
				<div class="clearfix"></div>
			</div>
		</div>
		<div class="modal-footer">
  		<div class="pull-left col-xs-9 text-left">
			<?php _e("Don't have an account?", 'liberty'); ?> <a href="<?php echo osc_user_login_url(); ?>"><?php _e("Sign up", 'liberty'); ?></a>
		</div>
		<button data-dismiss="modal" class="btn btn-primary" type="button"><?php _e("Close", 'liberty'); ?></button>
	</div>
	</div>
</div>
</div>


<!---- Model For Report ad ------------------------> 
<div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="spam" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h3 id="myModalLabel" class="modal-title"><?php _e("Why are you reporting this ad?", 'liberty'); ?></h3>
			</div>
			<div class="modal-body">
				<p></p>
				<?php //if(!osc_is_web_user_logged_in() || osc_logged_user_id()!=osc_item_user_id()) { ?>
            	<form action="<?php echo osc_base_url(true); ?>" method="post" name="mask_as_form" id="mask_as_form">
                <input type="hidden" name="id" value="<?php echo osc_item_id(); ?>" />
                <input type="hidden" name="as" value="spam" />
                <input type="hidden" name="action" value="mark" />
                <input type="hidden" name="page" value="item" />
          		<input id="as" type="radio" value="spam" name="as"/>&nbsp;&nbsp;<?php _e("This ad is a spam", 'liberty'); ?></br>
                <input id="as" type="radio" value="badcat" name="as"/>&nbsp;&nbsp;<?php _e("This ad is a misclassified", 'liberty'); ?></br>
                <input id="as" type="radio" value="repeated" name="as"/>&nbsp;&nbsp;<?php _e("This ad is a duplicated", 'liberty'); ?></br>
                <input id="as" type="radio" value="expired" name="as"/>&nbsp;&nbsp;<?php _e("This ad is a expired", 'liberty'); ?></br>
                <input id="as" type="radio" value="offensive" name="as"/>&nbsp;&nbsp;<?php _e("This ad is a offensive", 'liberty'); ?>
            	<?php //} ?>
			</div>
			<div class="modal-footer">
				<button class="btn btn-primary" type="submit"><?php _e("Send", 'liberty'); ?></button>
 				</form>
				<button data-dismiss="modal" class="btn btn-primary" type="button"><?php _e("Close", 'liberty'); ?></button>
			</div>
		</div>
	</div>
</div>


<!---- Model For Google Map ------------------------> 
<div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="showmap" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h4 id="myModalLabel" class="modal-title"><?php _e("Ad Location", 'liberty'); ?></h4>
				<small><?php _e("Please wait untill map loading...", 'liberty'); ?></small>
			</div>
			<div class="modal-body"><?php osc_run_hook('location'); ?></div>
            <div class="modal-footer">
				<button onClick="ResetMap();"  class="btn btn-primary" type="button"><?php _e("Reload", 'liberty'); ?></button>
				<button data-dismiss="modal" class="btn btn-primary" type="button"><?php _e("Close", 'liberty'); ?></button>
			</div>
		</div>
	</div>
</div>


<!---- Model For add to watchlist ------------------------> 
<div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="watchlist" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
            <div class="modal-header">
				<h3 id="myModalLabel" class="modal-title"><?php _e("Add this ad to your Watchlist", 'liberty'); ?></h3>
			</div>
            <?php if (function_exists("watchlist")) { ?>
			<div class="modal-body">
				<h4><?php echo osc_item_title(); ?></h4>
				<div id="description">
                	<p><?php echo osc_highlight( strip_tags( osc_item_description() ), 150) ; ?><?php //echo osc_item_description(); ?></p>
 					<p class="small"><em><?php if ( osc_item_pub_date() !== '' ) { printf( __('%1$s', 'liberty'), osc_format_date( osc_item_pub_date() ) ); } ?></em></p>
				</div>
            </div>
			<div class="modal-footer">
            	<?php if (function_exists("watchlist")) { ?>
                	<?php watchlist(); ?>&nbsp;&nbsp;&nbsp;
                <?php } ?>
					<button data-dismiss="modal" class="btn btn-primary" type="button"><?php _e("Close", 'liberty'); ?></button>
				</div>
			</div>
			<?php } else { echo "Plugin Missing...";} ?>
		</div>
	</div>
</div>

<!---- Model For Recover Password ------------------------> 
<div class="modal fade" id="forget" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h3 class="modal-title" id="myModalLabel"><?php _e('Recover your password', 'liberty'); ?> <a href="" class="pull-right" data-dismiss="modal"><small><?php _e("x", 'liberty'); ?></small></a></h3>
                <div class="clearfix"></div>
			</div>
            <form action="<?php echo osc_base_url(true); ?>" method="post" >
                    <input type="hidden" name="page" value="login" />
                    <input type="hidden" name="action" value="recover_post" />
           	<div class="modal-body">
            	
        			<p class="col-md-12"><?php _e('Your Email', 'liberty'); ?>:<p>
                    <div class="col-md-12">
                    	<?php UserForm::email_text(); ?>
                    </div>
                    <div class="clearfix"></div>
                   	<?php //osc_show_recaptcha('recover_password'); ?>
            	
        	</div>
			<div class="modal-footer">
				<button type="submit" class="btn btn-primary btn-md"><?php _e("Send", 'liberty');?></button>
                </form>
			</div>
		</div>
	</div>
</div>


<style>
.att.box h2 {
  font-size: 24px;
  padding-bottom: 5px;
  text-align: left;
}
</style>
<script type="text/javascript">
document.getElementById("email").setAttribute("placeholder","<?php _e("Email address", 'liberty'); ?>")
document.getElementById("password").setAttribute("placeholder","<?php _e("Password", 'liberty'); ?>")
</script>
<script type="text/javascript">
$(document).ready(function(){

    $(".watchlist span").addClass("btn btn-primary");
	
  });

</script>
<script type="text/javascript">
$(".wlogin").click(function(){
$(".fb-button a").addClass("btn fb-primary btn-lg col-md-12 col-xs-12");
$('.fb-button a').empty().append('<span class="hidden-xs"><?php _e("Login with Facebook", 'liberty'); ?></span> <span class="visible-xs"><?php _e("Login via FB", 'liberty'); ?></span>');
}); 
</script>
<script type="text/javascript">
$(document).ready(function(){
	$(".watchlist span").click(function(){
	$(".watchlist span a").hide();
 });
  });

</script>
<script type="text/javascript">
$(".wlist").click(function(){

    $(".watchlist span").addClass("btn btn-primary");
	
  });
</script>
<script type="text/javascript">
$('.related-items').each(function() {
    if ($.trim($(this).html()) == '') {
        $(this).parents('.box').css('display', 'none');
  }   
     });
</script>
<script type="text/javascript">
function ResetMap() {
google.maps.event.trigger(map, 'resize');
}
</script>
<script type="text/javascript">
$(document).ready(function() {
if ($('#showmap .modal-body').html().trim()) {
}
else
{
$('.mapbtn').remove();
}
if ($('.ifempty').html().trim()) {
}
else
{
$('.glocation').remove();
}
});
</script>
<script type="text/javascript">
$(document).ready(function() {
if ($('.att').html().trim()) {
}
else
{
$('.att').remove();
}
});

$(document).ready(function() {
if ($('.cmeta-empty').html().trim()) {
}
else
{
$('.cmeta').remove();
}
});
$(document).ready(function() {
if ($('.ifempty').html().trim()) {
}
else
{
$('.glocation').remove();
}
});
</script>

<script type="text/javascript">var switchTo5x=true;</script>
<script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
<script type="text/javascript">stLight.options({publisher: "5286ce33-bdc6-485e-8756-a52b6b5ef785", doNotHash: true, doNotCopy: true, hashAddressBar: false});</script>    
<?php ContactForm::js_validation(); ?>     
<?php osc_current_web_theme_path('footer.php') ; ?>