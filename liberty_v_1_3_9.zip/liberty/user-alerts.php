<?php
	 // meta tag robots
    osc_add_hook('header','liberty_nofollow_construct');

    liberty_add_body_class('user user-profile');
    osc_add_hook('before-main','sidebar');
    function sidebar(){
        osc_current_web_theme_path('user-sidebar.php');
    }
    osc_add_filter('meta_title_filter','custom_meta_title');
    function custom_meta_title($data){
        return __('Alerts', 'liberty');;
    }
    osc_current_web_theme_path('header.php') ;
    $osc_user = osc_user();
?>

<section id="myaccount">
    <div class="container">
		<div class="row">
        	<div class="col-md-3 hidden-xs hidden-sm">
            	<?php echo osc_current_web_theme_path('user-sidebar.php');?>
            </div>
           	<div class="col-md-9">
           		<div class="box">
                <?php UserForm::location_javascript(); ?>
                    	<h3><?php _e('Alerts', 'liberty'); ?></h3>
                        <div class="inner-wrapper">

		<?php if(osc_count_alerts() == 0) { ?>
            <p><?php _e('You do not have any alerts yet', 'liberty'); ?>.</p>
        <?php } else { ?>
    <?php
    $i = 1;
    while(osc_has_alerts()) { ?>
        <div class="userItem" >
            <div class="title-has-actions">
                <p><?php _e('Alert', 'liberty'); ?> <?php echo $i; ?></p> <a onclick="javascript:return confirm('<?php echo osc_esc_js(__('This action can\'t be undone. Are you sure you want to continue?', 'libertyw')); ?>');" href="<?php echo osc_user_unsubscribe_alert_url(); ?>"><?php _e('Delete this alert', 'liberty'); ?></a><div class="clear"></div></div>
            <div>
            <?php osc_current_web_theme_path('loop.php') ; ?>
            <?php if(osc_count_items() == 0) { ?>
                    <br />
                    0 <?php _e('Listings', 'liberty'); ?>
            <?php } ?>
            </div>
        </div>

        <br />
    <?php
    $i++;
    }
    ?>
<?php  } ?>
    </div>
    
            </div>
        </div>
        <div class="col-md-3 visible-xs visible-sm">
            	<?php echo osc_current_web_theme_path('user-sidebar.php');?>
            </div>
     	</div>
    </div>
</section>
<?php osc_current_web_theme_path('footer.php') ; ?>