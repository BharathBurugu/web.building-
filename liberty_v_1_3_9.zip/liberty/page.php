<?php osc_add_hook('header','bender_nofollow_construct');
	liberty_add_body_class('page');
    osc_current_web_theme_path('header.php') ;
	osc_reset_static_pages();
	
	 ?>
	
<section id="c-page">
    <div class="container">
		<div class="row">
       		<div class="col-md-12">
                    <div class="box">
                         <h3><?php echo osc_static_page_title(); ?></h3>
                        <?php echo osc_static_page_text(); ?>
                    </div>
                 </div>
           	</div>
         <div class="clearfix"></div>
     </div>
</section>   
    


<?php osc_current_web_theme_path('footer.php') ; ?>