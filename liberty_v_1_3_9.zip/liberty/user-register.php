<?php
// meta tag robots

    osc_add_hook('header','liberty_nofollow_construct');
    liberty_add_body_class('register');

	osc_enqueue_script('jquery-validate');
    osc_current_web_theme_path('header.php'); ?>
    

    
<section id="login">
    <div class="container">
    	<div class="row">
        	<div class="col-md-12">
        		<div class="box">
            		<div class="col-md-6 col-lg-6  hidden-xs hidden-sm first"><h3><?php _e('Sign in below', 'liberty'); ?> <small>- <?php _e('Welcome back', 'liberty'); ?>.</small></h3>
                    	<form action="<?php echo osc_base_url(true); ?>" class="form-horizontal" role="form" method="post" >
                    		<input type="hidden" name="page" value="login" />
                            <input type="hidden" name="action" value="login_post" />
                            <div class="col-md-12">
                            
                                    <?php UserForm::email_login_text(); ?>
                            </div>
                            <div class="clearfix"></div>
                            <br>
                            <div class="col-md-12">
                                <?php UserForm::password_login_text(); ?>
                            </div>
                            <div class="clearfix"></div>
                            <br />
                            <div class="col-md-6 col-xs-6">
                                <div class="checkbox">
                                    <?php UserForm::rememberme_login_checkbox(); ?> 
                                    <h4><small><?php _e('Stay signed in', 'liberty'); ?></small></h4>
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-6 text-right">              
                                <h4><a href="" data-target="#spam" data-toggle="modal"><small><?php _e('Forgot password?', 'liberty'); ?></small></a></h4>
                            </div>
                            <div class="clearfix"></div>
                            <br>
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-success btn-lg col-xs-12 col-md-12"><?php _e("Sign in", 'liberty'); ?></button>
                               
                            </div>
                            <?php if (function_exists("fbc_button")) { ?>
                            <br />
                            <div class="col-md-12 fb-button">
                            <?php fbc_button(); ?>
                     		</div>
                            <?php } ?>
                            
                               <div class="clearfix"></div>
                            <br />
                             <h4 class="text-center visible-xs visible-sm">
                             <a href="<?php echo osc_recover_user_password_url(); ?>"><small><?php _e('Forgot password?', 'liberty'); ?></small></a>
                             <a href="<?php echo osc_register_account_url(); ?>"><?php _e('Create an account', 'liberty'); ?></a></small></a></h4>
                        </form>
                    
                   
                    <div class="clearfix"></div>
                    </div>
                    
                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                        <form name="register" action="<?php echo osc_base_url(true); ?>" class="form-horizontal" role="form" method="post" >
                        	<input type="hidden" name="page" value="register" />
                        	<input type="hidden" name="action" value="register_post" />
                        	<h3><?php _e('Sign Up ', 'liberty'); ?>
                            <small>
                            <span class="hidden-sm hidden-xs">- <?php _e("It's free! No obligations", 'liberty'); ?>.</span>
                            <span class="hidden-lg hidden-md">- <?php _e('Sign in below', 'liberty'); ?><?php _e('Already Member?', 'liberty'); ?> <a href="<?php echo osc_user_login_url(); ?>"><?php _e('Login', 'liberty'); ?></a>.</span>
                            </small>
                            </h3>
                    		<div class="col-md-6 col-sm-6 col-xs-12">
                            	<?php UserForm::name_text(); ?>
                            </div>
                            <div class="visible-xs">
                            <div class="clearfix"></div>
                            <br>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                            	<?php UserForm::email_text(); ?>
                            </div>
                            
                            <div class="clearfix"></div>
                            <br>
                           
                            <div class="col-md-12">
                            	<?php UserForm::password_text(); ?>
                            </div>
                            <div class="clearfix"></div>
                            <br>
                            <div class="col-md-12">
                            	<?php UserForm::check_password_text(); ?>
                            </div>
                            <div class="clearfix"></div>
                            <br>
                            <div class="col-md-12">
                            	<?php UserForm::phone_land_text(); ?>
                            </div>
                            <div class="clearfix"></div>
                            <br>
                            <div class="col-md-12">
                            	<?php UserForm::website_text(); ?>
                            </div>
                            <div class="clearfix"></div>
                            <br>
                            <div class="col-md-12">
                           		<?php osc_run_hook('user_register_form'); ?>
                            </div>
                            <div class="clearfix"></div>
                            
                           
                      			<div class="col-md-12">
                        			<?php echo responsive_recaptcha(); ?>
									<?php osc_show_recaptcha('register'); ?>
                                </div>
                            	<div class="clearfix"></div>
                            	<br />
                        
                        
                        
                          
                            
                            	<div class="col-md-12">
                            <button type="submit" class="btn btn-success btn-lg col-md-12 col-sm-12 col-xs-12">
							<span class="hidden-xs"><?php _e("Create my free account", 'liberty'); ?> *</span><span class="visible-xs"><?php _e("Create account", 'liberty'); ?> *</span></button>
                            </div>
                         </form>
                        <div class="clearfix"></div>
                        <br>
                        	<h4 class="text-center terms"><small>* <?php _e("By signing up, you agree to our", 'liberty'); ?>
                            <a href="<?php echo osc_esc_html( osc_get_preference('terms_link', 'liberty_theme') ); ?>"><?php _e("Terms", 'liberty'); ?></a>
                             <?php _e("and", 'liberty'); ?> <a href="<?php echo osc_esc_html( osc_get_preference('privacy_link', 'liberty_theme') ); ?>"><?php _e("Privacy Policy", 'liberty'); ?></a></small></h4>
                        </div>
                        
                        <div class="clearfix"></div>

                    
            </div>
            </div>
		</div>
    </div>
</section>    

<div class="modal fade" id="spam" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h3 class="modal-title" id="myModalLabel"><?php _e('Recover your password', 'liberty'); ?> <small><a href="" class="pull-right" data-dismiss="modal">X</a></small></h3>
                
                       <div class="clearfix"></div>
			</div>
           
      <form action="<?php echo osc_base_url(true); ?>" method="post" >
                    <input type="hidden" name="page" value="login" />
                    <input type="hidden" name="action" value="recover_post" />
			<div class="modal-body">
                
        
                        <p class="col-md-12"><?php _e('Your Email', 'liberty'); ?>:<p>
                            <div class="col-md-12">
                                <?php UserForm::email_text(); ?>
                            </div>
                           <div class="clearfix"></div>
                        <?php //osc_show_recaptcha('recover_password'); ?>
            
                 
        	</div>
            </form>
			<div class="modal-footer">
				<button type="submit" class="btn btn-success btn-lg col-md-12"><span class="hidden-xs hedden-sm"><?php _e("Send me a new password", 'liberty');?></span>
				<span class="hidden-lg hedden-md"><?php _e("Send", 'liberty');?></button>
				
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
document.getElementById("email").setAttribute("placeholder","<?php _e("Email address", 'liberty'); ?>")
document.getElementById("password").setAttribute("placeholder","<?php _e("Password", 'liberty'); ?>")
document.getElementById("s_name").setAttribute("placeholder","<?php _e("Name", 'liberty'); ?>")
document.getElementById("s_email").setAttribute("placeholder","<?php _e("Email address", 'liberty'); ?>")
document.getElementById("s_password").setAttribute("placeholder","<?php _e("Password", 'liberty'); ?>")
document.getElementById("s_password2").setAttribute("placeholder","<?php _e("Repeat password", 'liberty'); ?>")
document.getElementById("s_phone_land").setAttribute("placeholder","<?php _e("Phone", 'liberty'); ?>")
document.getElementById("s_website").setAttribute("placeholder","<?php _e("Website", 'liberty'); ?>")




$(document).ready(function(){
$(".fb-button a").addClass("btn fb-primary btn-lg col-md-12 col-xs-12");
$('.fb-button a').empty().append('<span class="hidden-xs"><?php _e("Login with Facebook", 'liberty'); ?></span> <span class="visible-xs"><?php _e("Login via Fb", 'liberty'); ?></span>');
}); 


</script>
<?php UserForm::js_validation(); ?>    
<?php osc_current_web_theme_path('footer.php') ; ?>