<!DOCTYPE html>
<html dir="ltr" lang="<?php echo str_replace('_', '-', osc_current_user_locale()); ?>">
<head>
<meta charset="utf-8">
<title><?php echo meta_title() ; ?></title>
<meta name="title" content="<?php echo osc_esc_html(meta_title()); ?>" />
<?php if( meta_description() != '' ) { ?>
<meta name="description" content="<?php echo osc_esc_html(meta_description()); ?>" />
<?php } ?>
<?php if( meta_keywords() != '' ) { ?>
<meta name="keywords" content="<?php echo osc_esc_html(meta_keywords()); ?>" />
<?php } ?>
<?php if( osc_get_canonical() != '' ) { ?>
<!-- canonical -->
<link rel="canonical" href="<?php echo osc_get_canonical(); ?>"/>
<!-- /canonical -->
<?php } ?>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php if ( osc_is_ad_page() ) {?>
<!-- Open Graph Tags -->
<meta property="og:title" content="<?php echo osc_item_title(); ?>" />
<meta property="og:type" content="article" />
<meta property="og:image" content="<?php if( osc_count_item_resources() ) { ?><?php echo osc_resource_url(); ?><?php } ?>" />
<meta property="og:url" content="<?php echo osc_item_url(); ?>" />
<meta property="og:description" content="<?php echo osc_highlight( strip_tags( osc_item_description() ), 120 ) ; ?>" />
<!-- /Open Graph Tags -->
<?php } ?>
<!-- favicon -->
<link rel="shortcut icon" href="<?php echo osc_current_web_theme_url('favicon/favicon.ico'); ?>">
<!-- /favicon -->
<link href="<?php echo osc_current_web_theme_url('css/bootstrap.min.css') ; ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo osc_current_web_theme_url('css/style.css') ; ?>?ver=1.3.9" rel="stylesheet" type="text/css" />
<?php osc_run_hook('header'); ?>
<link type="text/css" rel="stylesheet" href="<?php echo osc_current_web_theme_url('css/mmenu.css') ; ?>" />
<link type="text/css" rel="stylesheet" href="<?php echo osc_current_web_theme_url('css/jquery.mmenu.css') ; ?>" />
<link type="text/css" rel="stylesheet" href="<?php echo osc_current_web_theme_url('js/jquery-ui/jquery-ui-1.10.2.custom.css') ; ?>" />
<link type="text/css" rel="stylesheet" href="<?php echo osc_current_web_theme_url('js/jquery-ui/jquery-ui-1.10.2.custom.min.css') ; ?>" />
<?php if(osc_is_publish_page()) { ?>
<script type="text/javascript" src="<?php echo osc_assets_url('js/jquery-ui.min.js')?>"></script>
<?php } ?>

<script src="<?php echo osc_current_web_theme_url('js/jquery.mmenu.min.js') ; ?>"></script>
<?php
 if( osc_get_preference('color_def', 'liberty_theme') != '1') { 
 osc_current_web_theme_path('css/colorcss.php');
 }?>
 <?php if(osc_get_preference('custom_css', 'liberty_theme', "UTF-8") !='') { ?>
<style>
 <?php echo osc_get_preference('custom_css', 'liberty_theme', "UTF-8"); ?>
</style>
<?php } ?>
</head>
<body <?php liberty_body_class(); ?>>
	<script type="text/javascript">
    $(function() {
    $('nav#menu').mmenu();
    });
    </script>
  	<div id="page">
        <section id="top">
            <div class="container">
                <div class="row">
                	
                    <div class="col-md-4 col-sm-4 hidden-xs logo <?php if ( osc_count_web_enabled_locales() > 1) { echo "m-aligment"; } ?>"><!------Logo------------>
                        <h1><?php echo logo_header(); ?></h1>
                    </div>
             

                 <div class="col-md-12 visible-xs text-center logo <?php if ( osc_count_web_enabled_locales() > 1) { echo "m-aligment"; } ?>"><!------Logo------------>
                        <h1><?php echo logo_header(); ?></h1>
                    </div>
                 
                    <div id="log-mobile" class="visible-xs text-center col-sm-12"><!------------- Post Button only on Small Screen--->
                        <ul class="nav">
                         <?php if( osc_users_enabled() || ( !osc_users_enabled() && !osc_reg_user_post() )) { ?>
                        <li class="reg"><a href="<?php echo osc_item_post_url(); ?>"><?php echo osc_esc_html( osc_get_preference('post_btn', 'liberty_theme') ); ?></a></li>
                         <?php } ?>
                         </ul>
                         </div>
                         
                         
                     
                    
                    <div class="col-md-8 menu hidden-xs"><!-------- Top Menu------------->
                        <div class="hidden-xs collapse navbar-collapse pull-right">
                            <ul class="nav navbar-nav">
                                 
                                        <ul class="nav navbar-nav navbar-right">
                                         <?php if( osc_get_preference('main_menu_home', 'liberty_theme') !== '0') { ?>
                                        <li><a href="<?php echo osc_base_url(); ?>"><?php _e('Home', 'liberty'); ?></a></li>
                                        <?php } ?>
                                        		<?php osc_reset_static_pages(); while( osc_has_static_pages() ) { ?>
                                                <?php if( osc_get_preference('main_menu_'.osc_static_page_id(), 'liberty_theme') !== '0') { ?>
                                                <li><a href="<?php echo osc_static_page_url(); ?>"><?php echo osc_static_page_title(); ?></a></li>
                                                 <?php } ?>
												 <?php } ?>
                                                 <?php if( osc_get_preference('main_menu_contact', 'liberty_theme') !== '0') { ?>
                                                <li><a href="<?php echo osc_contact_url(); ?>"><?php _e('Contact', 'liberty'); ?></a></li>
                                                <?php } ?>
                                                <?php if ( osc_count_web_enabled_locales() > 1) { ?>
                                                <li class="dropdown">
                                                	 <?php osc_goto_first_locale(); ?>
                                                	<a href="#" data-toggle="dropdown" class="dropdown-toggle"><?php $lng = osc_get_current_user_locale(); echo $lng['s_short_name']; ?><span class="caret"></span></a>
                                                    <?php $i = 0;  ?>
                                    				<ul role="menu" class="dropdown-menu">
                                                    	<?php while ( osc_has_web_enabled_locales() ) { ?>
                   										<?php if (osc_locale_code()!=osc_current_user_locale()) { ?>
                                        				<li><a id="<?php echo osc_locale_code(); ?>" rel="nofollow" href="<?php echo osc_change_language_url ( osc_locale_code() ); ?>"><?php echo osc_locale_name(); ?></a></li>
                                                        <?php $i++; ?>
                   										<?php } } ?>
                                                        <?php if( $i == 0 ) { echo ""; } ?>
                                                    </ul>
                								</li>
                                                <?php } ?>
  											</ul>
                                    
                                    </ul>
                                </div>
                            </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </section>
    
    <nav id="menu"><!----Mobile Menus--->
        <ul>
            <?php if( osc_get_preference('main_menu_home', 'liberty_theme') !== '0') { ?>
            <li><a href="<?php echo osc_base_url(); ?>"><?php _e('Home', 'liberty'); ?></a></li>
            <?php } ?>
                    <?php osc_reset_static_pages(); while( osc_has_static_pages() ) { ?>
                    <?php if( osc_get_preference('main_menu_'.osc_static_page_id(), 'liberty_theme') !== '0') { ?>
                    <li><a href="<?php echo osc_static_page_url(); ?>"><?php echo osc_static_page_title(); ?></a></li>
                     <?php } ?>
                     <?php } ?>
                     <?php if( osc_get_preference('main_menu_contact', 'liberty_theme') !== '0') { ?>
                    <li><a href="<?php echo osc_contact_url(); ?>"><?php _e('Contact', 'liberty'); ?></a></li>
                    <?php } ?>
             <?php if( osc_users_enabled() ) { ?>
            <?php if( osc_is_web_user_logged_in() ) { ?>
              <li><a href="<?php echo osc_user_dashboard_url(); ?>"><?php _e('Account Settings', 'liberty'); ?></a>

             
              <?php echo osc_private_user_menu( get_user_menu() ); ?>
            
              </li>
              <li><a href="<?php  echo osc_user_logout_url(); ?>"><?php _e('Logout', 'liberty'); ?></a></li>
            <?php } else { ?>
            <li><a href="<?php echo osc_user_login_url(); ?>"><?php _e('Login', 'liberty'); ?></a></li>
            <li><a href="<?php echo osc_register_account_url(); ?>"><?php _e('Register', 'liberty'); ?></a></li>
             <?php } ?>
              <?php } ?>
              <li><a><?php _e('Languages', 'liberty'); ?></a>
              
           <?php if ( osc_count_web_enabled_locales() > 1) { ?>
           <ul>
          		<?php osc_goto_first_locale(); ?>
    			<?php while ( osc_has_web_enabled_locales() ) { ?>
               <li><a id="<?php echo osc_locale_code(); ?>" rel="nofollow" href="<?php echo osc_change_language_url ( osc_locale_code() ); ?>"><?php echo osc_locale_name(); ?></a></li>			<?php  } ?>
             	<?php } ?>
                </ul>
                </li>
            
                                                    	
                                                    
                                                 
        </ul>
    </nav>
    
    
    <section id="head-bottom"><!----- Share Icons----->
        
        <div class="container">
            <div class="row">
                <div class="hidden-sm col-xs-1 col-md-3 col-lg-3">
               <?php if( osc_get_preference('facebook_opt', 'liberty_theme') == '1') { ?>
                    <a class="hidden-xs hidden-sm" target="_blank" href="https://facebook.com/<?php echo osc_esc_html( osc_get_preference('lbt_facebook', 'liberty_theme') ); ?>"><em class="fa fa-facebook"></em></a>
                <?php } ?>
                <?php if( osc_get_preference('google_opt', 'liberty_theme') == '1') { ?>
                    <a class="hidden-xs hidden-sm" target="_blank" href="https://plus.google.com/<?php echo osc_esc_html( osc_get_preference('lbt_googleplus', 'liberty_theme') ); ?>"><em class="fa fa-google-plus"></em></a>
                  <?php } ?>
                <?php if( osc_get_preference('twitter_opt', 'liberty_theme') == '1') { ?>
                    <a class="hidden-xs hidden-sm" target="_blank" href="https://twitter.com/<?php echo osc_esc_html( osc_get_preference('lbt_twitter', 'liberty_theme') ); ?>"><em class="fa fa-twitter"></em></a>
                 <?php } ?>
                    <a class="hidden-xs hidden-sm" target="_blank" href="https://plus.google.com/DrizzlethemesCom"><em class="fa fa-bar"></em></a>
                    <a class="visible-xs hidden-sm" href="#menu"><em class="fa fa-bars"></em></a>
                </div>
              	<div class="xs-search col-md-5 col-xs-10 col-sm-7 <?php if( osc_is_web_user_logged_in() ) { echo"col-lg-5"; } else  {echo "col-lg-6";} ?>"> <!---- Main search-------->
                    <form action="<?php echo osc_base_url(true); ?>" method="get" class="mainsearch nocsrf clearfix" <?php /* onsubmit="javascript:return doSearch();"*/ ?>>
                        <input type="hidden" name="page" value="search"/>
                        <span id="autowidth"></span>
                        <div class="input-group">
                            <input type="text" name="sPattern" id="query" class="form-control" value="" placeholder="<?php echo osc_esc_html(__(osc_get_preference('keyword_placeholder', 'liberty_theme'), 'liberty')); ?>" />
                            <span class="input-group-btn">
                                <button type="submit" class="hidden-xs btn btn-success"><?php _e('Search', 'liberty'); ?></button>
                                <button type="submit" class="visible-xs btn btn-success"><?php _e('Go', 'liberty'); ?></button>
                            </span>
                        </div>
                   	</form>
                 </div>
                <div id="log" class="col-md-4 col-sm-5 <?php if( osc_is_web_user_logged_in() ) { echo "col-lg-4"; } else  {echo "col-lg-3";} ?>"> <!------ Login menu ------->
             
					<ul class="nav pull-right">
                    	
                        <?php if( osc_users_enabled() ) { ?>
                            <?php if( osc_is_web_user_logged_in() ) { ?>
                            
                               <li class="dropdown hidden-xs">
                                
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                        <span class="glyphicon glyphicon-user"></span>&nbsp;
                                        <strong><?php _e('My account', 'liberty'); ?></strong>
                                    </a>
                           
                                    <ul role="menu" class="dropdown-menu">
                                    	
                                        <li><a href="<?php echo osc_user_dashboard_url(); ?>"><i class="fa fa-gear"></i> <?php _e('Dashboard', 'liberty'); ?></a></li>
                                        <li><a href="<?php  echo osc_user_logout_url(); ?>"><i class="fa fa-power-off"></i> <?php _e('Logout', 'liberty'); ?></a></li>
                                    </ul>
                                </li>
                            <?php } else{ ?>
                                <li class="hidden-xs"><a href="<?php echo osc_user_login_url(); ?>"><?php _e('Login', 'liberty'); ?></a></li>
                            <?php } ?>
                        <?php } ?>
                    			<li class="reg hidden-xs"><a href="<?php echo osc_item_post_url(); ?>"><?php echo osc_esc_html( osc_get_preference('post_btn', 'liberty_theme') ); ?></a></li>
    						</ul>
                </div>
            </div>
        </div>
    </section>
    
    
    
        <?php if (osc_show_flash_message()) { ?><!------------Error Msg------------->
    <div class="container">
        <div class="row">
            <div class="col-md-12 notification">
            	<div class="box">
                	<?php osc_show_flash_message(); ?>
                </div>
            </div>
        </div>
    </div>
    <?php } ?>
	
    <div class="clearfix"></div>