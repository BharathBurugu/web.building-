<?php /* Nothing but the rain */
